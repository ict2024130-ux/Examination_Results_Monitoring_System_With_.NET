#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  AR Office  -  payment sheets received from the HOD clerk.
	//                Open the sheet, pay, then mark it as paid (Sent to AR -> Paid).
	// ------------------------------------------------------------------
	public ref class ARPayment : public BasePage
	{
	private:
		ComboBox^ cmbFilter;
		DataGridView^ grid;
		Panel^ kWait;
		Panel^ kPaid;
		bool loading;

	public:
		ARPayment(Session^ s)
			: BasePage(s, L"Payment Sheets", L"Payment sheets submitted by the HOD clerk, ready for payment.")
		{
			loading = false;
			Build();
		}

		virtual void Reload() override
		{
			LoadGrid();
		}

	private:
		void Build()
		{
			kWait = Theme::Kpi(28, 92, 220, 84, L"AWAITING PAYMENT", L"0", Theme::Info);
			kPaid = Theme::Kpi(264, 92, 220, 84, L"PAID", L"0", Theme::Good);
			this->Controls->Add(kWait);
			this->Controls->Add(kPaid);

			Panel^ gc = Theme::Card(28, 196, 928, 440, L"Payment Sheets from HOD Clerk");
			gc->Controls->Add(Theme::Lbl(L"Show", 20, 56, 9.5f, FontStyle::Regular, Theme::Muted));
			cmbFilter = Theme::Combo(64, 52, 200);
			cmbFilter->Items->Add(L"Sent to AR");
			cmbFilter->Items->Add(L"Paid");
			cmbFilter->Items->Add(L"All");
			cmbFilter->SelectedIndex = 0;
			cmbFilter->SelectedIndexChanged += gcnew EventHandler(this, &ARPayment::DoFilter);
			gc->Controls->Add(cmbFilter);

			grid = Theme::Grid(20, 96, 888, 250);
			gc->Controls->Add(grid);

			Button^ bOpen = Theme::Btn(L"Open Payment Sheet", 20, 372, 190, 42, 1);
			Button^ bPaid = Theme::Btn(L"Mark as Paid", 224, 372, 170, 42, 0);
			bOpen->Click += gcnew EventHandler(this, &ARPayment::DoOpen);
			bPaid->Click += gcnew EventHandler(this, &ARPayment::DoPaid);
			gc->Controls->Add(bOpen);
			gc->Controls->Add(bPaid);

			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);
			SetScrollHeight(670);
		}

		void DoFilter(Object^ sender, EventArgs^ e)
		{
			if (loading) return;
			LoadGrid();
		}

		void LoadGrid()
		{
			try
			{
				loading = true;
				String^ f = Convert::ToString(cmbFilter->SelectedItem);
				DataTable^ dt = nullptr;
				if (f == L"All" || f->Length == 0)
					dt = Db::Query(Sql::PaymentSelect() + L"WHERE p.`Status` IN ('Sent to AR', 'Paid') ORDER BY FIELD(p.`Status`, 'Sent to AR', 'Paid'), p.Sheet_ID DESC");
				else
					dt = Db::Query(Sql::PaymentSelect() + L"WHERE p.`Status` = @st ORDER BY p.Sheet_ID DESC", L"@st", f);
				Theme::Bind(grid, dt);
				if (grid->Columns->Contains(L"Verified")) grid->Columns[L"Verified"]->Visible = false;
				if (grid->Columns->Contains(L"Uploaded")) grid->Columns[L"Uploaded"]->Visible = false;

				int wait = Db::ScalarInt(L"SELECT COUNT(*) FROM Payment_Sheet WHERE `Status` = 'Sent to AR'");
				int paid = Db::ScalarInt(L"SELECT COUNT(*) FROM Payment_Sheet WHERE `Status` = 'Paid'");
				Theme::SetKpi(kWait, wait.ToString());
				Theme::SetKpi(kPaid, paid.ToString());
				loading = false;
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

		void DoOpen(Object^ sender, EventArgs^ e)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Select a payment sheet first.");
				return;
			}
			String^ u = Theme::Str(r->Cells[L"AR Sheet URL"]->Value);
			if (u->Length == 0) u = Theme::Str(r->Cells[L"Sheet URL"]->Value);   // fall back to the lecturer's own link
			Theme::OpenLink(u);
		}

		void DoPaid(Object^ sender, EventArgs^ e)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Select a payment sheet first.");
				return;
			}
			if (Theme::Str(r->Cells[L"Status"]->Value) != L"Sent to AR")
			{
				Theme::MsgWarn(L"Only sheets with status \"Sent to AR\" can be marked as paid.");
				return;
			}
			String^ who = Theme::Str(r->Cells[L"Lecturer"]->Value);
			if (!Theme::Confirm(L"Mark the payment sheet of " + who + L" as paid?")) return;
			try
			{
				Db::Exec(
					L"UPDATE Payment_Sheet SET `Status` = 'Paid', Paid_By = @e, Paid_Date = CURDATE() WHERE Sheet_ID = @id AND `Status` = 'Sent to AR'",
					L"@e", S->EmployeeId, L"@id", Convert::ToInt32(r->Cells[L"ID"]->Value));
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}
