#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Second Examiner  -  document submission portal
	//    1. submit the second examiner report link   (Exam_Document, 'Second Examiner Report')
	//    2. open the lecturer-in-charge detail mark sheet   (Exam_Document, 'Mark Sheet')
	// ------------------------------------------------------------------
	public ref class secondExaminerDocument : public BasePage
	{
	private:
		ComboBox^ cmbCourse;
		TextBox^ txtCurrent;
		TextBox^ txtUrl;
		DateTimePicker^ dtpDate;
		TextBox^ txtLecturer;
		TextBox^ txtCourseId;
		TextBox^ txtMark;
		bool loading;

	public:
		secondExaminerDocument(Session^ s)
			: BasePage(s, L"Document Submission", L"Submit your second examiner report and open the lecturer's detail mark sheet.")
		{
			loading = false;
			Build();
		}

		virtual void Reload() override
		{
			try
			{
				loading = true;
				DataTable^ dt = Db::Query(
					L"SELECT ac.`Year` AS `Year`, ac.Semester_ID AS Semester_ID, ac.Course_Code AS Course_Code, "
					L"CONCAT(ac.`Year`, ' S', ac.Semester_ID, '  |  ', ac.Course_Code, ' - ', c.Name) AS Label, "
					L"IFNULL((SELECT GROUP_CONCAT(CONCAT(e2.First_Name, ' ', e2.Last_Name) SEPARATOR ', ') FROM Admin_Course a2 "
					L"JOIN Employee e2 ON e2.Employee_ID = a2.Employee_ID WHERE a2.`Year` = ac.`Year` AND a2.Semester_ID = ac.Semester_ID "
					L"AND a2.Course_Code = ac.Course_Code AND a2.Transaction_Type LIKE 'Lecturer in Charge%'), '') AS Lecturer, "
					L"IFNULL((SELECT d.Document_URL FROM Exam_Document d WHERE d.`Year` = ac.`Year` AND d.Semester_ID = ac.Semester_ID "
					L"AND d.Course_Code = ac.Course_Code AND d.Doc_Type = 'Mark Sheet'), '') AS MarkUrl, "
					L"IFNULL((SELECT d.Document_URL FROM Exam_Document d WHERE d.`Year` = ac.`Year` AND d.Semester_ID = ac.Semester_ID "
					L"AND d.Course_Code = ac.Course_Code AND d.Doc_Type = 'Second Examiner Report'), '') AS ReportUrl "
					L"FROM Admin_Course ac JOIN Course c ON c.Course_Code = ac.Course_Code "
					L"WHERE ac.Employee_ID = @e AND ac.Transaction_Type LIKE 'Second Examiner%' "
					L"ORDER BY ac.`Year` DESC, ac.Semester_ID DESC, ac.Course_Code",
					L"@e", S->EmployeeId);
				Theme::BindCombo(cmbCourse, dt, L"Label", L"Course_Code");
				loading = false;
				ShowCurrent();
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			Panel^ c1 = Theme::Card(28, 92, 640, 330, L"Second Examiner Report");
			cmbCourse = Theme::Combo(0, 0, 100);
			txtCurrent = Theme::Txt(0, 0, 100);
			txtCurrent->ReadOnly = true;
			txtCurrent->BackColor = Theme::Bg;
			txtUrl = Theme::Txt(0, 0, 100);
			txtUrl->MaxLength = 200;
			dtpDate = Theme::DatePick(0, 0, 100, false);
			Theme::Field(c1, L"Course", cmbCourse, 58);
			Theme::Field(c1, L"Current report", txtCurrent, 102);
			Theme::Field(c1, L"Report URL", txtUrl, 146);
			Theme::Field(c1, L"Submission date", dtpDate, 190);
			Button^ b1 = Theme::Btn(L"Submit Report", 160, 244, 190, 42, 0);
			Button^ b1o = Theme::Btn(L"Open Current Report", 362, 244, 180, 42, 1);
			b1->Click += gcnew EventHandler(this, &secondExaminerDocument::DoSubmit);
			b1o->Click += gcnew EventHandler(this, &secondExaminerDocument::DoOpenReport);
			c1->Controls->Add(b1);
			c1->Controls->Add(b1o);
			this->Controls->Add(c1);

			Panel^ c2 = Theme::Card(28, 442, 640, 270, L"Lecturer in Charge - Detail Mark Sheet");
			txtLecturer = Theme::Txt(0, 0, 100);
			txtCourseId = Theme::Txt(0, 0, 100);
			txtMark = Theme::Txt(0, 0, 100);
			txtLecturer->ReadOnly = true;
			txtCourseId->ReadOnly = true;
			txtMark->ReadOnly = true;
			txtLecturer->BackColor = Theme::Bg;
			txtCourseId->BackColor = Theme::Bg;
			txtMark->BackColor = Theme::Bg;
			Theme::Field(c2, L"Lecturer name", txtLecturer, 58);
			Theme::Field(c2, L"Course ID", txtCourseId, 102);
			Theme::Field(c2, L"Mark sheet", txtMark, 146);
			Button^ b2 = Theme::Btn(L"Open File", 160, 200, 190, 42, 0);
			b2->Click += gcnew EventHandler(this, &secondExaminerDocument::DoOpenMark);
			c2->Controls->Add(b2);
			this->Controls->Add(c2);

			Panel^ info = Theme::Card(688, 92, 280, 330, L"How it works");
			info->Controls->Add(Theme::Lbl(L"1.  Pick one of your courses.", 20, 58, 9.5f, FontStyle::Regular, Theme::Ink));
			info->Controls->Add(Theme::Lbl(L"2.  Open the lecturer's detail\n     mark sheet (below) and check it.", 20, 90, 9.5f, FontStyle::Regular, Theme::Ink));
			info->Controls->Add(Theme::Lbl(L"3.  Paste the link of your\n     second examiner report and\n     submit it.", 20, 144, 9.5f, FontStyle::Regular, Theme::Ink));
			info->Controls->Add(Theme::Lbl(L"Submitting again replaces the\nprevious report link.", 20, 226, 9.0f, FontStyle::Italic, Theme::Muted));
			this->Controls->Add(info);

			cmbCourse->SelectedIndexChanged += gcnew EventHandler(this, &secondExaminerDocument::DoCourseChanged);
			SetScrollHeight(740);
		}

		void ShowCurrent()
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r == nullptr)
			{
				txtCurrent->Text = L"";
				txtLecturer->Text = L"";
				txtCourseId->Text = L"";
				txtMark->Text = L"";
				return;
			}
			String^ rep = Theme::Str(r[L"ReportUrl"]);
			if (rep->Length == 0) rep = L"(nothing submitted yet)";
			txtCurrent->Text = rep;
			String^ lec = Theme::Str(r[L"Lecturer"]);
			if (lec->Length == 0) lec = L"(no lecturer in charge yet)";
			txtLecturer->Text = lec;
			txtCourseId->Text = Theme::Str(r[L"Course_Code"]);
			String^ mk = Theme::Str(r[L"MarkUrl"]);
			if (mk->Length == 0) mk = L"(not submitted by the lecturer yet)";
			txtMark->Text = mk;
		}

		void DoCourseChanged(Object^ sender, EventArgs^ e)
		{
			if (loading) return;
			ShowCurrent();
		}

		void DoSubmit(Object^ sender, EventArgs^ e)
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r == nullptr)
			{
				Theme::MsgWarn(L"You have no course assigned as second examiner.");
				return;
			}
			String^ url = txtUrl->Text->Trim();
			if (!Theme::IsWebLink(url))
			{
				Theme::MsgWarn(L"Please enter a valid link that starts with http:// or https://");
				return;
			}
			try
			{
				int idx = cmbCourse->SelectedIndex;
				Db::Exec(
					L"INSERT INTO Exam_Document (`Year`, Semester_ID, Course_Code, Doc_Type, Document_URL, Submitted_By, Submitted_Date) "
					L"VALUES (@y, @s, @c, 'Second Examiner Report', @u, @e, @d) "
					L"ON DUPLICATE KEY UPDATE Document_URL = @u, Submitted_By = @e, Submitted_Date = @d",
					L"@y", Convert::ToInt32(r[L"Year"]), L"@s", Convert::ToInt32(r[L"Semester_ID"]),
					L"@c", Convert::ToString(r[L"Course_Code"]), L"@u", url, L"@e", S->EmployeeId, L"@d", Theme::DateValue(dtpDate));
				txtUrl->Clear();
				Reload();
				if (idx >= 0 && idx < cmbCourse->Items->Count) cmbCourse->SelectedIndex = idx;
				Theme::MsgInfo(L"Second examiner report submitted.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoOpenReport(Object^ sender, EventArgs^ e)
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r != nullptr) Theme::OpenLink(Theme::Str(r[L"ReportUrl"]));
		}

		void DoOpenMark(Object^ sender, EventArgs^ e)
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r != nullptr) Theme::OpenLink(Theme::Str(r[L"MarkUrl"]));
		}
	};
}
