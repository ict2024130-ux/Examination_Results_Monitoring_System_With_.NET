#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  AR Office: add courses / exam offerings, collect answer-script packets,
	//  record EIS update and hand packets over.
	// ------------------------------------------------------------------
	public ref class AROFFICE : public BasePage
	{
	private:
		TextBox^ txtCode;
		TextBox^ txtName;
		TextBox^ txtDesc;

		ComboBox^ cmbSem;
		ComboBox^ cmbCourse;
		DateTimePicker^ dtpExam;
		NumericUpDown^ numScripts;
		ComboBox^ cmbStatus;

		ComboBox^ cmbCollect;
		DateTimePicker^ dtpCollect;
		NumericUpDown^ numPackets;

		ComboBox^ cmbHand;
		DateTimePicker^ dtpEis;
		DateTimePicker^ dtpHand;

		DataGridView^ grid;

	public:
		AROFFICE(Session^ s)
			: BasePage(s, L"AR Office", L"Register courses and exams, collect packets and hand them over.")
		{
			Build();
		}

		virtual void Reload() override
		{
			try
			{
				Theme::BindCombo(cmbSem, Db::Query(Sql::SemesterList()), L"Label", L"K");
				Theme::BindCombo(cmbCourse, Db::Query(Sql::CourseList()), L"Label", L"Course_Code");
				ReloadOfferings();
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			// ---------- Course ADD ----------
			Panel^ c1 = Theme::Card(28, 92, 480, 330, L"Course ADD");
			txtCode = Theme::Txt(0, 0, 100);
			txtCode->MaxLength = 10;
			txtName = Theme::Txt(0, 0, 100);
			txtName->MaxLength = 50;
			txtDesc = Theme::Txt(0, 0, 100);
			txtDesc->MaxLength = 100;
			Theme::Field(c1, L"Course code", txtCode, 58);
			Theme::Field(c1, L"Course name", txtName, 102);
			Theme::Field(c1, L"Description", txtDesc, 146);
			Button^ b1 = Theme::Btn(L"ADD Course", 160, 204, 160, 42, 0);
			b1->Click += gcnew EventHandler(this, &AROFFICE::DoAddCourse);
			c1->Controls->Add(b1);
			this->Controls->Add(c1);

			// ---------- Exam offering ----------
			Panel^ c2 = Theme::Card(528, 92, 480, 330, L"Exam Offering");
			cmbSem = Theme::Combo(0, 0, 100);
			cmbCourse = Theme::Combo(0, 0, 100);
			dtpExam = Theme::DatePick(0, 0, 100, false);
			numScripts = Theme::Num(0, 0, 100, 0, 5000, 0);
			cmbStatus = Theme::Combo(0, 0, 100);
			cmbStatus->Items->Add(L"Scheduled");
			cmbStatus->Items->Add(L"Completed");
			cmbStatus->Items->Add(L"Postponed");
			cmbStatus->Items->Add(L"Cancelled");
			cmbStatus->SelectedIndex = 0;
			Theme::Field(c2, L"Semester", cmbSem, 58);
			Theme::Field(c2, L"Course", cmbCourse, 102);
			Theme::Field(c2, L"Exam date", dtpExam, 146);
			Theme::Field(c2, L"Answer scripts", numScripts, 190);
			Theme::Field(c2, L"Status", cmbStatus, 234);
			Button^ b2 = Theme::Btn(L"Save Offering", 160, 276, 160, 42, 0);
			b2->Click += gcnew EventHandler(this, &AROFFICE::DoSaveOffering);
			c2->Controls->Add(b2);
			this->Controls->Add(c2);

			// ---------- Packet collect ----------
			Panel^ c3 = Theme::Card(28, 442, 480, 270, L"Paper Packet COLLECT");
			cmbCollect = Theme::Combo(0, 0, 100);
			dtpCollect = Theme::DatePick(0, 0, 100, false);
			numPackets = Theme::Num(0, 0, 100, 0, 5000, 0);
			Theme::Field(c3, L"Exam", cmbCollect, 58);
			Theme::Field(c3, L"Collect date", dtpCollect, 102);
			Theme::Field(c3, L"Packet count", numPackets, 146);
			Button^ b3 = Theme::Btn(L"COLLECT", 160, 204, 160, 42, 0);
			b3->Click += gcnew EventHandler(this, &AROFFICE::DoCollect);
			c3->Controls->Add(b3);
			this->Controls->Add(c3);

			// ---------- EIS + hand over ----------
			Panel^ c4 = Theme::Card(528, 442, 480, 270, L"EIS Update & Hand Over");
			cmbHand = Theme::Combo(0, 0, 100);
			dtpEis = Theme::DatePick(0, 0, 100, false);
			dtpHand = Theme::DatePick(0, 0, 100, false);
			Theme::Field(c4, L"Exam", cmbHand, 58);
			Theme::Field(c4, L"EIS update date", dtpEis, 102);
			Theme::Field(c4, L"Hand over date", dtpHand, 146);
			Button^ b4 = Theme::Btn(L"Record EIS Update", 160, 204, 148, 42, 1);
			Button^ b5 = Theme::Btn(L"HAND OVER", 318, 204, 142, 42, 0);
			b4->Click += gcnew EventHandler(this, &AROFFICE::DoEis);
			b5->Click += gcnew EventHandler(this, &AROFFICE::DoHandOver);
			c4->Controls->Add(b4);
			c4->Controls->Add(b5);
			this->Controls->Add(c4);

			// ---------- board ----------
			Panel^ gc = Theme::Card(28, 732, 980, 330, L"Packet Status Board");
			grid = Theme::Grid(20, 54, 940, 256);
			gc->Controls->Add(grid);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);

			SetScrollHeight(1090);
		}

		void ReloadOfferings()
		{
			String^ sql =
				L"SELECT o.`Year` AS `Year`, o.Semester_ID AS Semester_ID, o.Course_Code AS Course_Code, "
				L"CONCAT(o.`Year`, ' S', o.Semester_ID, '  |  ', o.Course_Code, ' - ', c.Name) AS Label "
				L"FROM Exam_Offering o JOIN Course c ON c.Course_Code = o.Course_Code "
				L"ORDER BY o.`Year` DESC, o.Semester_ID DESC, o.Course_Code";
			DataTable^ dt = Db::Query(sql);
			Theme::BindCombo(cmbCollect, dt, L"Label", L"Course_Code");
			Theme::BindCombo(cmbHand, dt->Copy(), L"Label", L"Course_Code");
		}

		void LoadGrid()
		{
			Theme::Bind(grid, Db::Query(Sql::TrackingSelect() + Sql::TrackingOrder()));
		}

		// reads Year / Semester / Course from an "exam" combo; false (with a message) if none selected
		bool ExamKey(ComboBox^ cb, int% year, int% sem, String^% code)
		{
			DataRow^ r = Theme::RowOf(cb);
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Please select an exam. Create the exam offering first if the list is empty.");
				return false;
			}
			year = Convert::ToInt32(r[L"Year"]);
			sem = Convert::ToInt32(r[L"Semester_ID"]);
			code = Convert::ToString(r[L"Course_Code"]);
			return true;
		}

		void DoAddCourse(Object^ sender, EventArgs^ e)
		{
			String^ code = txtCode->Text->Trim()->ToUpper();
			String^ name = txtName->Text->Trim();
			String^ desc = txtDesc->Text->Trim();
			if (code->Length == 0 || name->Length == 0 || desc->Length == 0)
			{
				Theme::MsgWarn(L"Course code, name and description are all required.");
				return;
			}
			try
			{
				if (Db::ScalarInt(L"SELECT COUNT(*) FROM Course WHERE Course_Code = @c", L"@c", code) > 0)
				{
					Theme::MsgWarn(L"A course with code " + code + L" already exists.");
					return;
				}
				Db::Exec(L"INSERT INTO Course (Course_Code, Name, Description) VALUES (@c, @n, @d)", L"@c", code, L"@n", name, L"@d", desc);
				txtCode->Clear();
				txtName->Clear();
				txtDesc->Clear();
				Reload();
				Theme::MsgInfo(L"Course " + code + L" added.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoSaveOffering(Object^ sender, EventArgs^ e)
		{
			DataRow^ s = Theme::RowOf(cmbSem);
			DataRow^ c = Theme::RowOf(cmbCourse);
			if (s == nullptr || c == nullptr)
			{
				Theme::MsgWarn(L"Please select a semester and a course.");
				return;
			}
			try
			{
				Db::Exec(
					L"INSERT INTO Exam_Offering (`Year`, Semester_ID, Course_Code, Exam_Date, Answer_Script_Count, `Status`) "
					L"VALUES (@y, @s, @c, @d, @n, @st) "
					L"ON DUPLICATE KEY UPDATE Exam_Date = @d, Answer_Script_Count = @n, `Status` = @st",
					L"@y", Convert::ToInt32(s[L"Year"]), L"@s", Convert::ToInt32(s[L"Semester_ID"]),
					L"@c", Convert::ToString(c[L"Course_Code"]), L"@d", Theme::DateValue(dtpExam),
					L"@n", Decimal::ToInt32(numScripts->Value), L"@st", Convert::ToString(cmbStatus->SelectedItem));
				Reload();
				Theme::MsgInfo(L"Exam offering saved.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoCollect(Object^ sender, EventArgs^ e)
		{
			int year = 0;
			int sem = 0;
			String^ code = nullptr;
			if (!ExamKey(cmbCollect, year, sem, code)) return;
			int n = Decimal::ToInt32(numPackets->Value);
			if (n <= 0)
			{
				Theme::MsgWarn(L"Enter the number of packets collected.");
				return;
			}
			try
			{
				Db::Exec(
					L"INSERT INTO Exam_Packet_Tracking (`Year`, Semester_ID, Course_Code, Packet_Submission_Date, Packet_Count) "
					L"VALUES (@y, @s, @c, @d, @n) "
					L"ON DUPLICATE KEY UPDATE Packet_Submission_Date = @d, Packet_Count = @n",
					L"@y", year, L"@s", sem, L"@c", code, L"@d", Theme::DateValue(dtpCollect), L"@n", n);
				LoadGrid();
				Theme::MsgInfo(L"Packets collected for " + code + L".");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		// the packet must have been collected before EIS update / hand over
		bool CollectedOn(int year, int sem, String^ code, DateTime% when)
		{
			Object^ o = Db::Scalar(
				L"SELECT Packet_Submission_Date FROM Exam_Packet_Tracking WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c",
				L"@y", year, L"@s", sem, L"@c", code);
			if (o == nullptr || Convert::IsDBNull(o))
			{
				Theme::MsgWarn(L"The packets of " + code + L" have not been collected yet. Use COLLECT first.");
				return false;
			}
			when = Convert::ToDateTime(o);
			return true;
		}

		void DoEis(Object^ sender, EventArgs^ e)
		{
			int year = 0;
			int sem = 0;
			String^ code = nullptr;
			if (!ExamKey(cmbHand, year, sem, code)) return;
			try
			{
				DateTime collected = DateTime::Now;
				if (!CollectedOn(year, sem, code, collected)) return;
				Db::Exec(
					L"UPDATE Exam_Packet_Tracking SET EIS_Update_Date = @d WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c",
					L"@d", Theme::DateValue(dtpEis), L"@y", year, L"@s", sem, L"@c", code);
				LoadGrid();
				Theme::MsgInfo(L"EIS update recorded for " + code + L".");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoHandOver(Object^ sender, EventArgs^ e)
		{
			int year = 0;
			int sem = 0;
			String^ code = nullptr;
			if (!ExamKey(cmbHand, year, sem, code)) return;
			try
			{
				DateTime collected = DateTime::Now;
				if (!CollectedOn(year, sem, code, collected)) return;
				DateTime d = dtpHand->Value.Date;
				if (DateTime::Compare(d, collected.Date) < 0)
				{
					Theme::MsgWarn(L"The hand over date cannot be earlier than the collect date (" + collected.ToString(L"yyyy-MM-dd") + L").");
					return;
				}
				DbTx^ tx = gcnew DbTx();
				try
				{
					tx->Exec(
						L"UPDATE Exam_Packet_Tracking SET Handover_Date = @d WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c",
						L"@d", d, L"@y", year, L"@s", sem, L"@c", code);
					tx->Exec(
						L"INSERT INTO Hand_Over (Employee_ID, Course_Code, `Date`) VALUES (@e, @c, @d) "
						L"ON DUPLICATE KEY UPDATE `Date` = @d",
						L"@e", S->EmployeeId, L"@c", code, L"@d", d);
					tx->Commit();
				}
				catch (Exception^)
				{
					tx->Rollback();
					throw;
				}
				LoadGrid();
				Theme::MsgInfo(L"Packets of " + code + L" handed over.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}
