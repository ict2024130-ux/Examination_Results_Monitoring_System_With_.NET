#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Employee directory.  HOD: update / delete.  Dean (DEANTRAKING): read only.
	// ------------------------------------------------------------------
	public ref class HODTraking : public BasePage
	{
	private:
		bool canEdit;
		bool loading;
		String^ origQual;
		DataTable^ dtEmp;
		TextBox^ txtSearch;
		DataGridView^ gridEmp;
		DataGridView^ gridCourses;
		TextBox^ txtId;
		TextBox^ txtFirst;
		TextBox^ txtLast;
		TextBox^ txtA1;
		TextBox^ txtA2;
		TextBox^ txtEmail;
		TextBox^ txtContact;
		TextBox^ txtQual;
		TextBox^ txtRoles;

	public:
		HODTraking(Session^ s)
			: BasePage(s, L"Employee Management", L"Search employees, update their details or remove them.")
		{
			canEdit = true;
			loading = false;
			origQual = L"";
			Build();
		}

	protected:
		HODTraking(Session^ s, String^ title, String^ subtitle, bool edit)
			: BasePage(s, title, subtitle)
		{
			canEdit = edit;
			loading = false;
			origQual = L"";
			Build();
		}

	public:
		virtual void Reload() override
		{
			try
			{
				LoadEmployees();
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			Panel^ ca = Theme::Card(28, 92, 940, 330, L"Employees");
			ca->Controls->Add(Theme::Lbl(L"Search", 20, 56, 9.5f, FontStyle::Regular, Theme::Muted));
			txtSearch = Theme::Txt(80, 52, 280);
			txtSearch->TextChanged += gcnew EventHandler(this, &HODTraking::DoSearch);
			ca->Controls->Add(txtSearch);
			ca->Controls->Add(Theme::Lbl(L"(employee ID or name)", 372, 56, 9.0f, FontStyle::Italic, Theme::Muted));
			gridEmp = Theme::Grid(20, 92, 900, 218);
			gridEmp->SelectionChanged += gcnew EventHandler(this, &HODTraking::DoSelected);
			ca->Controls->Add(gridEmp);
			this->Controls->Add(ca);
			StretchX(ca);
			StretchIn(gridEmp, ca);

			String^ titleB = canEdit ? L"Employee Details" : L"Employee Details (read only)";
			Panel^ cb = Theme::Card(28, 442, 480, 490, titleB);
			txtId = Theme::Txt(0, 0, 100);
			txtId->ReadOnly = true;
			txtId->BackColor = Theme::Bg;
			txtFirst = Theme::Txt(0, 0, 100);
			txtLast = Theme::Txt(0, 0, 100);
			txtA1 = Theme::Txt(0, 0, 100);
			txtA2 = Theme::Txt(0, 0, 100);
			txtEmail = Theme::Txt(0, 0, 100);
			txtContact = Theme::Txt(0, 0, 100);
			txtQual = Theme::Txt(0, 0, 100);
			txtRoles = Theme::Txt(0, 0, 100);
			txtRoles->ReadOnly = true;
			txtRoles->BackColor = Theme::Bg;
			txtFirst->MaxLength = 50;
			txtLast->MaxLength = 50;
			txtA1->MaxLength = 50;
			txtA2->MaxLength = 50;
			txtEmail->MaxLength = 50;
			txtContact->MaxLength = 10;
			txtQual->MaxLength = 50;

			Theme::Field(cb, L"Employee ID", txtId, 58);
			Theme::Field(cb, L"First name", txtFirst, 98);
			Theme::Field(cb, L"Last name", txtLast, 138);
			Theme::Field(cb, L"Address line 1", txtA1, 178);
			Theme::Field(cb, L"Address line 2", txtA2, 218);
			Theme::Field(cb, L"E-mail", txtEmail, 258);
			Theme::Field(cb, L"Contact number", txtContact, 298);
			Theme::Field(cb, L"Qualification", txtQual, 338);
			Theme::Field(cb, L"Roles", txtRoles, 378);

			if (canEdit)
			{
				Button^ btnUp = Theme::Btn(L"Update", 160, 428, 140, 42, 0);
				Button^ btnDel = Theme::Btn(L"Delete", 312, 428, 140, 42, 2);
				btnUp->Click += gcnew EventHandler(this, &HODTraking::DoUpdate);
				btnDel->Click += gcnew EventHandler(this, &HODTraking::DoDelete);
				cb->Controls->Add(btnUp);
				cb->Controls->Add(btnDel);
			}
			else
			{
				txtFirst->ReadOnly = true;
				txtLast->ReadOnly = true;
				txtA1->ReadOnly = true;
				txtA2->ReadOnly = true;
				txtEmail->ReadOnly = true;
				txtContact->ReadOnly = true;
				txtQual->ReadOnly = true;
			}
			this->Controls->Add(cb);

			Panel^ cc = Theme::Card(528, 442, 440, 490, L"Course Involvement");
			gridCourses = Theme::Grid(20, 54, 400, 416);
			cc->Controls->Add(gridCourses);
			this->Controls->Add(cc);
			StretchX(cc);
			StretchIn(gridCourses, cc);

			SetScrollHeight(960);
		}

		void LoadEmployees()
		{
			int keep = 0;
			if (gridEmp->CurrentRow != nullptr) keep = Convert::ToInt32(gridEmp->CurrentRow->Cells[L"ID"]->Value);

			// read-only users (Dean) see the MASKED view: addresses hidden, e-mail and phone partly hidden
			String^ src = canEdit ? L"Employee" : L"v_employee_directory_masked";
			loading = true;
			dtEmp = Db::Query(
				L"SELECT e.Employee_ID AS `ID`, e.First_Name AS `First Name`, e.Last_Name AS `Last Name`, e.Email AS `Email`, "
				L"e.Contact_Number AS `Contact`, "
				L"IFNULL((SELECT GROUP_CONCAT(q.Qualification SEPARATOR ', ') FROM Employee_Qualification q WHERE q.Employee_ID = e.Employee_ID), '') AS `Qualification`, "
				L"CONCAT_WS(', ', (SELECT a.`Type` FROM `Admin` a WHERE a.Employee_ID = e.Employee_ID), "
				L"IF(EXISTS(SELECT 1 FROM Lecturer_in_Charge x WHERE x.Employee_ID = e.Employee_ID), 'Lecturer in Charge', NULL), "
				L"IF(EXISTS(SELECT 1 FROM Second_Examiner y WHERE y.Employee_ID = e.Employee_ID), 'Second Examiner', NULL), "
				L"IF(EXISTS(SELECT 1 FROM Moderator z WHERE z.Employee_ID = e.Employee_ID), 'Moderator', NULL)) AS `Roles` "
				L"FROM " + src + L" e ORDER BY e.Employee_ID");
			Theme::Bind(gridEmp, dtEmp);
			loading = false;
			DoSearch(nullptr, nullptr);
			if (keep > 0) SelectRow(keep);
			DoSelected(nullptr, nullptr);
		}

		void SelectRow(int id)
		{
			for (int i = 0; i < gridEmp->Rows->Count; i++)
			{
				if (Convert::ToInt32(gridEmp->Rows[i]->Cells[L"ID"]->Value) == id)
				{
					gridEmp->CurrentCell = gridEmp->Rows[i]->Cells[0];
					return;
				}
			}
		}

		void DoSearch(Object^ sender, EventArgs^ e)
		{
			if (dtEmp == nullptr) return;
			String^ t = txtSearch->Text->Trim();
			t = t->Replace(L"'", L"''")->Replace(L"[", L"")->Replace(L"]", L"")->Replace(L"*", L"")->Replace(L"%", L"");
			if (t->Length == 0) dtEmp->DefaultView->RowFilter = L"";
			else dtEmp->DefaultView->RowFilter = L"[First Name] LIKE '%" + t + L"%' OR [Last Name] LIKE '%" + t +
				L"%' OR Convert([ID], 'System.String') LIKE '%" + t + L"%'";
		}

		void ClearDetails()
		{
			txtId->Clear();
			txtFirst->Clear();
			txtLast->Clear();
			txtA1->Clear();
			txtA2->Clear();
			txtEmail->Clear();
			txtContact->Clear();
			txtQual->Clear();
			txtRoles->Clear();
			origQual = L"";
			gridCourses->DataSource = nullptr;
		}

		void DoSelected(Object^ sender, EventArgs^ e)
		{
			if (loading) return;
			DataGridViewRow^ r = gridEmp->CurrentRow;
			if (r == nullptr)
			{
				ClearDetails();
				return;
			}
			try
			{
				int id = Convert::ToInt32(r->Cells[L"ID"]->Value);
				String^ src = canEdit ? L"Employee" : L"v_employee_directory_masked";
				DataTable^ dt = Db::Query(L"SELECT * FROM " + src + L" WHERE Employee_ID = @id", L"@id", id);
				if (dt->Rows->Count == 0)
				{
					ClearDetails();
					return;
				}
				DataRow^ x = dt->Rows[0];
				txtId->Text = id.ToString();
				txtFirst->Text = Convert::ToString(x[L"First_Name"]);
				txtLast->Text = Convert::ToString(x[L"Last_Name"]);
				txtA1->Text = Convert::ToString(x[L"Adress_Line_1"]);
				txtA2->Text = Convert::ToString(x[L"Adress_Line_2"]);
				txtEmail->Text = Convert::ToString(x[L"Email"]);
				txtContact->Text = Convert::ToString(x[L"Contact_Number"]);
				origQual = Theme::Str(r->Cells[L"Qualification"]->Value);
				txtQual->Text = origQual;
				txtRoles->Text = Theme::Str(r->Cells[L"Roles"]->Value);

				DataTable^ ct = Db::Query(
					L"SELECT ac.`Year` AS `Year`, ac.Semester_ID AS `Sem`, ac.Course_Code AS `Course Code`, c.Name AS `Course Name`, "
					L"ac.Transaction_Type AS `Role / Transaction`, "
					L"CASE WHEN p.Handover_Date IS NOT NULL THEN 'Handed over' WHEN p.EIS_Update_Date IS NOT NULL THEN 'EIS updated' "
					L"WHEN p.Packet_Submission_Date IS NOT NULL THEN 'Packet submitted' ELSE 'Pending' END AS `Stage` "
					L"FROM Admin_Course ac JOIN Course c ON c.Course_Code = ac.Course_Code "
					L"LEFT JOIN Exam_Packet_Tracking p ON p.`Year` = ac.`Year` AND p.Semester_ID = ac.Semester_ID AND p.Course_Code = ac.Course_Code "
					L"WHERE ac.Employee_ID = @id ORDER BY ac.`Year` DESC, ac.Semester_ID DESC, ac.Course_Code", L"@id", id);
				Theme::Bind(gridCourses, ct);
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoUpdate(Object^ sender, EventArgs^ e)
		{
			if (txtId->Text->Length == 0)
			{
				Theme::MsgWarn(L"Select an employee first.");
				return;
			}
			String^ err = CheckEmployee(txtFirst->Text, txtLast->Text, txtA1->Text, txtA2->Text, txtEmail->Text, txtContact->Text);
			if (err->Length > 0)
			{
				Theme::MsgWarn(err);
				return;
			}
			String^ q = txtQual->Text->Trim();
			if (q->Length == 0)
			{
				Theme::MsgWarn(L"Qualification is required.");
				return;
			}
			int id = Convert::ToInt32(txtId->Text);
			try
			{
				DbTx^ tx = gcnew DbTx();
				try
				{
					tx->Exec(
						L"UPDATE Employee SET First_Name = @fn, Last_Name = @ln, Adress_Line_1 = @a1, Adress_Line_2 = @a2, "
						L"Email = @em, Contact_Number = @ct WHERE Employee_ID = @id",
						L"@fn", txtFirst->Text->Trim(), L"@ln", txtLast->Text->Trim(), L"@a1", txtA1->Text->Trim(),
						L"@a2", txtA2->Text->Trim(), L"@em", txtEmail->Text->Trim(), L"@ct", txtContact->Text->Trim(), L"@id", id);
					if (q != origQual)
					{
						tx->Exec(L"DELETE FROM Employee_Qualification WHERE Employee_ID = @id", L"@id", id);
						tx->Exec(L"INSERT INTO Employee_Qualification (Employee_ID, Qualification) VALUES (@id, @q)", L"@id", id, L"@q", q);
					}
					tx->Commit();
				}
				catch (Exception^)
				{
					tx->Rollback();
					throw;
				}
				LoadEmployees();
				Theme::MsgInfo(L"Employee updated.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoDelete(Object^ sender, EventArgs^ e)
		{
			if (txtId->Text->Length == 0)
			{
				Theme::MsgWarn(L"Select an employee first.");
				return;
			}
			int id = Convert::ToInt32(txtId->Text);
			if (id == S->EmployeeId)
			{
				Theme::MsgWarn(L"You cannot delete your own account.");
				return;
			}
			if (!Theme::Confirm(L"Delete employee " + id.ToString() + L" (" + txtFirst->Text + L" " + txtLast->Text +
				L") together with the login, roles and course assignments?\nThis cannot be undone.")) return;
			try
			{
				DbTx^ tx = gcnew DbTx();
				try
				{
					array<String^>^ tables = gcnew array<String^>{ L"Hand_Over", L"Admin_Course", L"Users", L"Lecturer_in_Charge",
						L"Second_Examiner", L"Moderator", L"`Admin`", L"Employee_Qualification", L"Employee" };
					// payment / document tables exist only after ERMS_update.sql has been run
					try
					{
						tx->Exec(L"UPDATE Payment_Sheet SET Verified_By = NULL WHERE Verified_By = @id", L"@id", id);
						tx->Exec(L"UPDATE Payment_Sheet SET Forwarded_By = NULL WHERE Forwarded_By = @id", L"@id", id);
						tx->Exec(L"UPDATE Payment_Sheet SET Paid_By = NULL WHERE Paid_By = @id", L"@id", id);
						tx->Exec(L"DELETE FROM Payment_Sheet WHERE Employee_ID = @id", L"@id", id);
					}
					catch (Exception^) {}
					try { tx->Exec(L"DELETE FROM Exam_Document WHERE Submitted_By = @id", L"@id", id); }
					catch (Exception^) {}
					for each (String ^ t in tables)
						tx->Exec(L"DELETE FROM " + t + L" WHERE Employee_ID = @id", L"@id", id);
					tx->Commit();
				}
				catch (Exception^)
				{
					tx->Rollback();
					throw;
				}
				// remove the employee's MySQL account too (ignored if the procedure / account does not exist)
				try { Db::Exec(L"CALL Drop_Employee_Account(@id)", L"@id", id); }
				catch (Exception^) {}
				origQual = L"";
				LoadEmployees();
				Theme::MsgInfo(L"Employee deleted.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}