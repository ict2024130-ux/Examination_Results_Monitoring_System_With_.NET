#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Tracking of the courses assigned to the logged-in employee.
	//  roleLike = 'Lecturer in Charge%' | 'Second Examiner%' | 'Moderator%'
	// ------------------------------------------------------------------
	public ref class TrakingDetails : public BasePage
	{
	private:
		String^ roleLike;
		DataGridView^ grid;
		Panel^ kpiTotal;
		Panel^ kpiSubmitted;
		Panel^ kpiEis;
		Panel^ kpiHand;

	public:
		TrakingDetails(Session^ s)
			: BasePage(s, L"Exam Packet Tracking", L"Follow every course from packet submission to hand-over.")
		{
			roleLike = L"Lecturer in Charge%";
			Build();
		}

	protected:
		TrakingDetails(Session^ s, String^ title, String^ subtitle, String^ like)
			: BasePage(s, title, subtitle)
		{
			roleLike = like;
			Build();
		}

	public:
		virtual void Reload() override
		{
			try
			{
				DataTable^ dt = Db::Query(Sql::TrackingSelect() + Sql::AssignedFilter() + Sql::TrackingOrder(),
					L"@emp", S->EmployeeId, L"@tt", roleLike);
				Theme::Bind(grid, dt);

				int sub = 0, eis = 0, hand = 0;
				for each (DataRow^ r in dt->Rows)
				{
					String^ st = Theme::Str(r[L"Stage"]);
					if (st == L"Packet submitted" || st == L"EIS updated" || st == L"Handed over") sub++;
					if (st == L"EIS updated" || st == L"Handed over") eis++;
					if (st == L"Handed over") hand++;
				}
				Theme::SetKpi(kpiTotal, dt->Rows->Count.ToString());
				Theme::SetKpi(kpiSubmitted, sub.ToString());
				Theme::SetKpi(kpiEis, eis.ToString());
				Theme::SetKpi(kpiHand, hand.ToString());
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			kpiTotal = Theme::Kpi(28, 92, 220, 84, L"MY COURSES", L"0", Theme::Brand);
			kpiSubmitted = Theme::Kpi(264, 92, 220, 84, L"PACKETS SUBMITTED", L"0", Theme::Warn);
			kpiEis = Theme::Kpi(500, 92, 220, 84, L"EIS UPDATED", L"0", Theme::Info);
			kpiHand = Theme::Kpi(736, 92, 220, 84, L"HANDED OVER", L"0", Theme::Good);
			this->Controls->Add(kpiTotal);
			this->Controls->Add(kpiSubmitted);
			this->Controls->Add(kpiEis);
			this->Controls->Add(kpiHand);

			Panel^ gc = Theme::Card(28, 196, 928, 420, L"Course Tracking");
			grid = Theme::Grid(20, 54, 888, 340);
			gc->Controls->Add(grid);
			Button^ btnRefresh = Theme::Btn(L"Refresh", 0, 12, 100, 32, 1);
			btnRefresh->Left = 800;
			btnRefresh->Click += gcnew EventHandler(this, &TrakingDetails::DoRefresh);
			gc->Controls->Add(btnRefresh);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);
			SetScrollHeight(650);
		}

		void DoRefresh(Object^ sender, EventArgs^ e)
		{
			Reload();
		}
	};
}
