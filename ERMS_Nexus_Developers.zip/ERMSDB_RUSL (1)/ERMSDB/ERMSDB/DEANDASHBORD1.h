#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Dean dashboard: faculty-wide monitoring of all exam packets
	// ------------------------------------------------------------------
	public ref class DEANDASHBORD : public BasePage
	{
	private:
		ComboBox^ cmbSem;
		DataGridView^ grid;
		bool loading;
		Panel^ k0;
		Panel^ k1;
		Panel^ k2;
		Panel^ k3;
		Panel^ k4;
		Panel^ k5;

	public:
		DEANDASHBORD(Session^ s)
			: BasePage(s, L"Dean Dashboard", L"Monitor every course from exam to packet hand-over.")
		{
			loading = false;
			Build();
		}

		virtual void Reload() override
		{
			try
			{
				loading = true;
				DataTable^ sem = Db::Query(Sql::SemesterList());
				Theme::BindCombo(cmbSem, Theme::WithNone(sem, L"Year", L"Label", L"All semesters"), L"Label", L"K");
				cmbSem->SelectedIndex = 0;
				loading = false;
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			Panel^ banner = WelcomeBanner(28, 92, 900);
			StretchX(banner);
			this->Controls->Add(banner);

			k0 = Theme::Kpi(28, 178, 150, 84, L"COURSES", L"0", Theme::Brand);
			k1 = Theme::Kpi(188, 178, 150, 84, L"EXAMS DONE", L"0", Theme::Good);
			k2 = Theme::Kpi(348, 178, 150, 84, L"SCHEDULED", L"0", Theme::Info);
			k3 = Theme::Kpi(508, 178, 150, 84, L"PACKETS IN", L"0", Theme::Warn);
			k4 = Theme::Kpi(668, 178, 150, 84, L"EIS UPDATED", L"0", Theme::Gold);
			k5 = Theme::Kpi(828, 178, 150, 84, L"HANDED OVER", L"0", Theme::Good);
			this->Controls->Add(k0);
			this->Controls->Add(k1);
			this->Controls->Add(k2);
			this->Controls->Add(k3);
			this->Controls->Add(k4);
			this->Controls->Add(k5);

			Panel^ gc = Theme::Card(28, 282, 950, 470, L"Course Monitoring Board");
			gc->Controls->Add(Theme::Lbl(L"Semester", 20, 56, 9.5f, FontStyle::Regular, Theme::Muted));
			cmbSem = Theme::Combo(90, 52, 260);
			cmbSem->SelectedIndexChanged += gcnew EventHandler(this, &DEANDASHBORD::DoFilter);
			gc->Controls->Add(cmbSem);
			Button^ btnRef = Theme::Btn(L"Refresh", 366, 50, 100, 32, 1);
			btnRef->Click += gcnew EventHandler(this, &DEANDASHBORD::DoRefresh);
			gc->Controls->Add(btnRef);

			grid = Theme::Grid(20, 96, 910, 350);
			gc->Controls->Add(grid);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);
			SetScrollHeight(780);
		}

		void DoFilter(Object^ sender, EventArgs^ e)
		{
			if (loading) return;
			LoadGrid();
		}

		void DoRefresh(Object^ sender, EventArgs^ e)
		{
			Reload();
		}

		void LoadGrid()
		{
			DataRow^ sem = Theme::RowOf(cmbSem);
			DataTable^ dt = nullptr;
			if (sem == nullptr || Convert::IsDBNull(sem[L"Year"]))
			{
				dt = Db::Query(Sql::TrackingSelect() + Sql::TrackingOrder());
			}
			else
			{
				dt = Db::Query(Sql::TrackingSelect() + L"WHERE k.`Year` = @y AND k.Semester_ID = @s" + Sql::TrackingOrder(),
					L"@y", Convert::ToInt32(sem[L"Year"]), L"@s", Convert::ToInt32(sem[L"Semester_ID"]));
			}
			Theme::Bind(grid, dt);

			int done = 0, sched = 0, sub = 0, eis = 0, hand = 0;
			for each (DataRow^ r in dt->Rows)
			{
				String^ status = Theme::Str(r[L"Status"]);
				if (status == L"Completed") done++;
				if (status == L"Scheduled") sched++;
				String^ st = Theme::Str(r[L"Stage"]);
				if (st == L"Packet submitted" || st == L"EIS updated" || st == L"Handed over") sub++;
				if (st == L"EIS updated" || st == L"Handed over") eis++;
				if (st == L"Handed over") hand++;
			}
			Theme::SetKpi(k0, dt->Rows->Count.ToString());
			Theme::SetKpi(k1, done.ToString());
			Theme::SetKpi(k2, sched.ToString());
			Theme::SetKpi(k3, sub.ToString());
			Theme::SetKpi(k4, eis.ToString());
			Theme::SetKpi(k5, hand.ToString());
		}
	};
}
