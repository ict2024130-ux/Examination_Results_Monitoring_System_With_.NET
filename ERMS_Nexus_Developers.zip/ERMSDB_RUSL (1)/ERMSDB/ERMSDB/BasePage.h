#pragma once
#include "Theme.h"
#include "Db.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Drawing::Drawing2D;
	using namespace System::Windows::Forms;
	using namespace System::Collections::Generic;

	// ------------------------------------------------------------------
	//  Base class of every screen shown inside the main window.
	//  Reload() is called each time the screen is displayed.
	// ------------------------------------------------------------------
	public ref class BasePage abstract : public Panel
	{
	protected:
		Session^ S;
		List<Control^>^ stretchList;
		List<Control^>^ kidList;
		List<Control^>^ kidParentList;
		Label^ lblTitle;
		Label^ lblSub;

	public:
		BasePage(Session^ s, String^ title, String^ subtitle)
		{
			S = s;
			stretchList = gcnew List<Control^>();
			kidList = gcnew List<Control^>();
			kidParentList = gcnew List<Control^>();
			this->Dock = DockStyle::Fill;
			this->BackColor = Theme::Bg;
			this->AutoScroll = true;
			this->Visible = false;

			lblTitle = Theme::Lbl(title, 28, 18, 20.0f, FontStyle::Bold, Theme::Brand);
			lblSub = Theme::Lbl(subtitle, 31, 58, 10.0f, FontStyle::Regular, Theme::Muted);
			this->Controls->Add(lblTitle);
			this->Controls->Add(lblSub);
			this->SizeChanged += gcnew EventHandler(this, &BasePage::DoPageSize);
		}

		virtual void Reload() {}

	protected:
		// control is stretched horizontally with the page (right margin 28 px)
		void StretchX(Control^ c)
		{
			stretchList->Add(c);
		}

		// child (inside a card that is itself stretched) keeps a 20 px right margin
		void StretchIn(Control^ child, Control^ parentCard)
		{
			kidList->Add(child);
			kidParentList->Add(parentCard);
		}

		void DoPageSize(Object^ sender, EventArgs^ e)
		{
			int w = this->ClientSize.Width;
			for each (Control^ c in stretchList)
			{
				int nw = w - c->Left - 28;
				if (nw < 360) nw = 360;
				c->Width = nw;
			}
			for (int i = 0; i < kidList->Count; i++)
			{
				int kw = kidParentList[i]->Width - kidList[i]->Left - 20;
				if (kw < 100) kw = 100;
				kidList[i]->Width = kw;
			}
		}

		void SetScrollHeight(int h)
		{
			this->AutoScrollMinSize = System::Drawing::Size(1000, h);
		}

		// Validation shared by the "add employee" and "update employee" forms. Returns "" when everything is fine.
		static String^ CheckEmployee(String^ fn, String^ ln, String^ a1, String^ a2, String^ email, String^ contact)
		{
			if (fn->Trim()->Length == 0) return L"First name is required.";
			if (ln->Trim()->Length == 0) return L"Last name is required.";
			if (a1->Trim()->Length == 0) return L"Address line 1 is required.";
			if (a2->Trim()->Length == 0) return L"Address line 2 is required.";
			String^ em = email->Trim();
			if (em->Length < 5 || !em->Contains(L"@") || !em->Contains(L".")) return L"Please enter a valid e-mail address.";
			String^ ct = contact->Trim();
			if (ct->Length != 10) return L"Contact number must be exactly 10 digits (for example 0712345678).";
			for (int i = 0; i < ct->Length; i++)
			{
				if (!Char::IsDigit(ct[i])) return L"Contact number must contain digits only.";
			}
			return L"";
		}

		// Profile card with avatar, role chip and contact details of the logged-in employee
		Panel^ ProfileCard(int x, int y, int w)
		{
			Panel^ card = Theme::Card(x, y, w, 236, nullptr);

			Label^ av = gcnew Label();
			av->SetBounds(20, 22, 64, 64);
			av->BackColor = Theme::Brand;
			av->ForeColor = Color::White;
			av->Font = Theme::Face(18.0f, FontStyle::Bold);
			av->TextAlign = ContentAlignment::MiddleCenter;
			av->Text = S->Initials();
			GraphicsPath^ gp = gcnew GraphicsPath();
			gp->AddEllipse(0, 0, 64, 64);
			av->Region = gcnew System::Drawing::Region(gp);
			card->Controls->Add(av);

			card->Controls->Add(Theme::Lbl(S->FullName(), 98, 26, 14.0f, FontStyle::Bold, Theme::Ink));

			Label^ chip = Theme::Lbl(L"  " + S->Role + L"  ", 98, 58, 9.0f, FontStyle::Bold, Theme::Brand);
			chip->BackColor = Theme::BrandSoft;
			card->Controls->Add(chip);

			Panel^ sep = gcnew Panel();
			sep->SetBounds(20, 100, w - 40, 1);
			sep->BackColor = Theme::Line;
			card->Controls->Add(sep);

			String^ q = S->Qualification;
			if (q->Length == 0) q = L"-";
			array<String^>^ caps = gcnew array<String^>{ L"Employee ID", L"Qualification", L"Email", L"Contact" };
			array<String^>^ vals = gcnew array<String^>{ S->EmployeeId.ToString(), q, S->Email, S->Contact };
			for (int i = 0; i < 4; i++)
			{
				card->Controls->Add(Theme::Lbl(caps[i], 20, 112 + i * 28, 9.0f, FontStyle::Regular, Theme::Muted));
				card->Controls->Add(Theme::Lbl(vals[i], 130, 111 + i * 28, 10.0f, FontStyle::Regular, Theme::Ink));
			}
			return card;
		}

		// Thin banner shown on top of dashboards: "Welcome, <name>"
		Panel^ WelcomeBanner(int x, int y, int w)
		{
			Panel^ p = gcnew Panel();
			p->SetBounds(x, y, w, 70);
			p->BackColor = Theme::Brand;
			Image^ bg = Theme::LoadImage(L"header_banner.png");
			if (bg != nullptr)
			{
				p->BackgroundImage = bg;
				p->BackgroundImageLayout = ImageLayout::Stretch;
			}
			p->Controls->Add(Theme::Lbl(L"Welcome, " + S->FirstName, 22, 10, 15.0f, FontStyle::Bold, Color::White));
			p->Controls->Add(Theme::Lbl(S->Role + L"  |  Rajarata University of Sri Lanka", 24, 40, 9.5f, FontStyle::Regular, Theme::Gold));
			return p;
		}
	};
}
