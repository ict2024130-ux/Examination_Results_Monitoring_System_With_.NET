#pragma once
#include "secondExaminer.h"

namespace ERMSDB {

	// Moderator dashboard: same layout as the second examiner, plus document verification
	public ref class ModaretorDashBord : public secondExaminer
	{
	public:
		ModaretorDashBord(Session^ s)
			: secondExaminer(s, L"Moderator Dashboard", L"Review and verify the exam documents of your courses.",
				L"Moderator%", L"Moderator", true)
		{
		}
	};
}
