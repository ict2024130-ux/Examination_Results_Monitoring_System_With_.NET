#pragma once
// ============================================================================
//  Theme.h  -  Rajarata University of Sri Lanka look & feel + UI helpers
//  Colours are taken from the university crest (maroon + gold).
// ============================================================================

namespace ERMSDB {

	using namespace System;
	using namespace System::IO;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Drawing::Drawing2D;
	using namespace System::Drawing::Text;
	using namespace System::Windows::Forms;
	using namespace System::Collections::Generic;
	using namespace System::Diagnostics;

	public ref class Theme abstract sealed
	{
	public:
		// ---------------- palette ----------------
		static property Color Brand{ Color get() { return Color::FromArgb(122, 18, 32); } }
		static property Color BrandDark{ Color get() { return Color::FromArgb(59, 0, 0); } }
		static property Color BrandSoft{ Color get() { return Color::FromArgb(246, 226, 228); } }
		static property Color Gold{ Color get() { return Color::FromArgb(201, 151, 36); } }
		static property Color Bg{ Color get() { return Color::FromArgb(246, 243, 240); } }
		static property Color Ink{ Color get() { return Color::FromArgb(43, 33, 33); } }
		static property Color Muted{ Color get() { return Color::FromArgb(112, 100, 100); } }
		static property Color Line{ Color get() { return Color::FromArgb(226, 218, 214); } }
		static property Color Good{ Color get() { return Color::FromArgb(22, 128, 60); } }
		static property Color Warn{ Color get() { return Color::FromArgb(181, 110, 0); } }
		static property Color Bad{ Color get() { return Color::FromArgb(178, 34, 34); } }
		static property Color Info{ Color get() { return Color::FromArgb(30, 90, 160); } }

			// ---------------- fonts ----------------
			static System::Drawing::Font^ Face(float pt, FontStyle st)
		{
			return gcnew System::Drawing::Font(L"Segoe UI", pt, st, GraphicsUnit::Point);
		}

		// ---------------- images ----------------
		static String^ FindAsset(String^ name)
		{
			array<String^>^ roots = gcnew array<String^>{
				Path::Combine(Application::StartupPath, L"Images"),
				Path::Combine(Application::StartupPath, L"..\\assets"),
				Path::Combine(Application::StartupPath, L"..\\..\\assets"),
				Path::Combine(Application::StartupPath, L"..\\..\\..\\assets"),
				Path::Combine(Application::StartupPath, L"assets")
			};
			for each(String ^ r in roots)
			{
				String^ p = Path::Combine(r, name);
				if (File::Exists(p)) return p;
			}
			return nullptr;
		}

		// Loads an image without locking the file. Returns nullptr when not found.
		static Image^ LoadImage(String^ name)
		{
			String^ p = FindAsset(name);
			if (p == nullptr) return nullptr;
			try
			{
				Image^ im = Image::FromFile(p);
				Bitmap^ b = gcnew Bitmap(im);
				delete im;
				return b;
			}
			catch (Exception^)
			{
				return nullptr;
			}
		}

		// Draws one Segoe MDL2 Assets glyph into a bitmap (used for menu / button icons)
		static Bitmap^ Glyph(String^ glyph, int px, Color c)
		{
			Bitmap^ b = gcnew Bitmap(px, px);
			Graphics^ g = Graphics::FromImage(b);
			g->TextRenderingHint = TextRenderingHint::AntiAliasGridFit;
			System::Drawing::Font^ f = gcnew System::Drawing::Font(L"Segoe MDL2 Assets", (float)px * 0.62f, FontStyle::Regular, GraphicsUnit::Pixel);
			SolidBrush^ br = gcnew SolidBrush(c);
			StringFormat^ sf = gcnew StringFormat();
			sf->Alignment = StringAlignment::Center;
			sf->LineAlignment = StringAlignment::Center;
			g->DrawString(glyph, f, br, RectangleF(0.0f, 0.0f, (float)px, (float)px), sf);
			delete br;
			delete g;
			return b;
		}

		// ---------------- message boxes ----------------
		static void MsgInfo(String^ msg)
		{
			MessageBox::Show(msg, L"Examination Report Monitoring System", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		static void MsgWarn(String^ msg)
		{
			MessageBox::Show(msg, L"Examination Report Monitoring System", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		}
		static void Fail(Exception^ ex)
		{
			MessageBox::Show(L"Database operation failed:\n\n" + ex->Message, L"Examination Report Monitoring System",
				MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		static bool Confirm(String^ msg)
		{
			return MessageBox::Show(msg, L"Please confirm", MessageBoxButtons::YesNo, MessageBoxIcon::Question) == DialogResult::Yes;
		}

		// ---------------- value helpers ----------------
		static String^ Str(Object^ o)
		{
			if (o == nullptr || Convert::IsDBNull(o)) return L"";
			if (o->GetType()->Equals(DateTime::typeid))
			{
				DateTime d = Convert::ToDateTime(o);
				return d.ToString(L"yyyy-MM-dd");
			}
			return o->ToString();
		}

		static bool IsWebLink(String^ s)
		{
			if (s == nullptr) return false;
			Uri^ u = nullptr;
			if (!Uri::TryCreate(s->Trim(), UriKind::Absolute, u)) return false;
			return u->Scheme == L"http" || u->Scheme == L"https";
		}

		// opens a http/https link in the default browser (with a message if the link is missing / invalid)
		static void OpenLink(String^ url)
		{
			if (!IsWebLink(url))
			{
				MsgWarn(L"There is no valid link (http / https) to open.");
				return;
			}
			try { Process::Start(url->Trim()); }
			catch (Exception^ ex) { Fail(ex); }
		}

		static Object^ NullIfEmpty(String^ s)
		{
			if (s == nullptr || s->Trim()->Length == 0) return DBNull::Value;
			return s->Trim();
		}

		// DateTimePicker (optionally with a check box) -> value for SQL
		static Object^ DateValue(DateTimePicker^ d)
		{
			if (d->ShowCheckBox && !d->Checked) return DBNull::Value;
			DateTime v = d->Value.Date;
			return v;
		}

		static void SetDate(DateTimePicker^ d, Object^ val)
		{
			if (val == nullptr || Convert::IsDBNull(val))
			{
				if (d->ShowCheckBox) d->Checked = false;
				return;
			}
			d->Value = Convert::ToDateTime(val);
			if (d->ShowCheckBox) d->Checked = true;
		}

		// ---------------- control factories ----------------
		static Label^ Lbl(String^ text, int x, int y, float pt, FontStyle st, Color c)
		{
			Label^ l = gcnew Label();
			l->Text = text;
			l->AutoSize = true;
			l->UseMnemonic = false;      // show "&" literally (e.g. "Course & Examiner Selection")
			l->Location = System::Drawing::Point(x, y);
			l->Font = Face(pt, st);
			l->ForeColor = c;
			l->BackColor = Color::Transparent;
			return l;
		}

		// kind: 0 = primary (maroon)  1 = outline  2 = danger  3 = gold
		static Button^ Btn(String^ text, int x, int y, int w, int h, int kind)
		{
			Button^ b = gcnew Button();
			b->Text = text;
			b->SetBounds(x, y, w, h);
			b->FlatStyle = FlatStyle::Flat;
			b->Cursor = Cursors::Hand;
			b->Font = Face(10.0f, FontStyle::Bold);
			b->UseVisualStyleBackColor = false;
			b->FlatAppearance->BorderSize = 0;
			if (kind == 0)
			{
				b->BackColor = Brand;
				b->ForeColor = Color::White;
				b->FlatAppearance->MouseOverBackColor = BrandDark;
				b->FlatAppearance->MouseDownBackColor = BrandDark;
			}
			else if (kind == 1)
			{
				b->BackColor = Color::White;
				b->ForeColor = Brand;
				b->FlatAppearance->BorderSize = 1;
				b->FlatAppearance->BorderColor = Brand;
				b->FlatAppearance->MouseOverBackColor = BrandSoft;
				b->FlatAppearance->MouseDownBackColor = BrandSoft;
			}
			else if (kind == 2)
			{
				b->BackColor = Bad;
				b->ForeColor = Color::White;
				b->FlatAppearance->MouseOverBackColor = Color::FromArgb(140, 20, 20);
				b->FlatAppearance->MouseDownBackColor = Color::FromArgb(140, 20, 20);
			}
			else
			{
				b->BackColor = Gold;
				b->ForeColor = BrandDark;
				b->FlatAppearance->MouseOverBackColor = Color::FromArgb(224, 176, 60);
				b->FlatAppearance->MouseDownBackColor = Color::FromArgb(224, 176, 60);
			}
			return b;
		}

		static TextBox^ Txt(int x, int y, int w)
		{
			TextBox^ t = gcnew TextBox();
			t->Font = Face(10.0f, FontStyle::Regular);
			t->Location = System::Drawing::Point(x, y);
			t->Width = w;
			t->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			t->ForeColor = Ink;
			return t;
		}

		static ComboBox^ Combo(int x, int y, int w)
		{
			ComboBox^ c = gcnew ComboBox();
			c->Font = Face(10.0f, FontStyle::Regular);
			c->Location = System::Drawing::Point(x, y);
			c->Width = w;
			c->DropDownStyle = ComboBoxStyle::DropDownList;
			c->FlatStyle = FlatStyle::Flat;
			c->BackColor = Color::White;
			c->ForeColor = Ink;
			return c;
		}

		static DateTimePicker^ DatePick(int x, int y, int w, bool nullable)
		{
			DateTimePicker^ d = gcnew DateTimePicker();
			d->Font = Face(10.0f, FontStyle::Regular);
			d->Location = System::Drawing::Point(x, y);
			d->Width = w;
			d->Format = DateTimePickerFormat::Custom;
			d->CustomFormat = L"yyyy-MM-dd";
			d->ShowCheckBox = nullable;
			if (nullable) d->Checked = false;
			return d;
		}

		static NumericUpDown^ Num(int x, int y, int w, int minV, int maxV, int val)
		{
			NumericUpDown^ n = gcnew NumericUpDown();
			n->Font = Face(10.0f, FontStyle::Regular);
			n->Location = System::Drawing::Point(x, y);
			n->Width = w;
			n->Minimum = minV;
			n->Maximum = maxV;
			n->Value = val;
			return n;
		}

		// ---------------- cards ----------------
		static void CardPaint(Object^ sender, PaintEventArgs^ e)
		{
			Control^ c = safe_cast<Control^>(sender);
			Pen^ pen = gcnew Pen(Line);
			e->Graphics->DrawRectangle(pen, 0, 0, c->Width - 1, c->Height - 1);
			delete pen;
			SolidBrush^ br = gcnew SolidBrush(Gold);
			e->Graphics->FillRectangle(br, 0, 0, c->Width, 3);
			delete br;
		}

		static Panel^ Card(int x, int y, int w, int h, String^ title)
		{
			Panel^ p = gcnew Panel();
			p->SetBounds(x, y, w, h);
			p->BackColor = Color::White;
			p->Paint += gcnew PaintEventHandler(&Theme::CardPaint);
			if (title != nullptr && title->Length > 0)
			{
				p->Controls->Add(Lbl(title, 20, 16, 12.0f, FontStyle::Bold, Brand));
			}
			return p;
		}

		// label on the left + control on the right inside a card
		static void Field(Panel^ card, String^ caption, Control^ ctl, int y)
		{
			card->Controls->Add(Lbl(caption, 20, y + 4, 9.5f, FontStyle::Regular, Muted));
			ctl->Location = System::Drawing::Point(160, y);
			ctl->Width = card->Width - 160 - 20;
			ctl->Anchor = AnchorStyles::Top | AnchorStyles::Left | AnchorStyles::Right;
			card->Controls->Add(ctl);
		}

		// small KPI tile; the value label is kept in Tag
		static Panel^ Kpi(int x, int y, int w, int h, String^ caption, String^ value, Color accent)
		{
			Panel^ p = gcnew Panel();
			p->SetBounds(x, y, w, h);
			p->BackColor = Color::White;
			p->Paint += gcnew PaintEventHandler(&Theme::KpiPaint);
			p->Tag = nullptr;
			Panel^ bar = gcnew Panel();
			bar->SetBounds(0, 0, 6, h);
			bar->BackColor = accent;
			p->Controls->Add(bar);
			p->Controls->Add(Lbl(caption, 20, 12, 9.0f, FontStyle::Regular, Muted));
			Label^ v = Lbl(value, 18, 32, 22.0f, FontStyle::Bold, Ink);
			p->Controls->Add(v);
			p->Tag = v;
			return p;
		}

		static void KpiPaint(Object^ sender, PaintEventArgs^ e)
		{
			Control^ c = safe_cast<Control^>(sender);
			Pen^ pen = gcnew Pen(Line);
			e->Graphics->DrawRectangle(pen, 0, 0, c->Width - 1, c->Height - 1);
			delete pen;
		}

		static void SetKpi(Panel^ kpi, String^ value)
		{
			Label^ l = dynamic_cast<Label^>(kpi->Tag);
			if (l != nullptr) l->Text = value;
		}

		// ---------------- grid ----------------
		static void GridFormatting(Object^ sender, DataGridViewCellFormattingEventArgs^ e)
		{
			if (e->RowIndex < 0 || e->ColumnIndex < 0 || e->Value == nullptr) return;
			DataGridView^ g = safe_cast<DataGridView^>(sender);
			String^ col = g->Columns[e->ColumnIndex]->Name;
			if (col != L"Stage" && col != L"Verification" && col != L"Status") return;
			String^ v = e->Value->ToString();
			if (v == L"Handed over" || v == L"Verified" || v == L"Completed" || v == L"Paid") e->CellStyle->ForeColor = Good;
			else if (v == L"EIS updated" || v == L"Scheduled" || v == L"Sent to AR") e->CellStyle->ForeColor = Info;
			else if (v == L"Packet submitted" || v == L"Pending verification" || v == L"Uploaded") e->CellStyle->ForeColor = Warn;
			else if (v == L"Pending" || v == L"Cancelled" || v == L"Rejected") e->CellStyle->ForeColor = Bad;
			else return;
			e->CellStyle->Font = Face(9.5f, FontStyle::Bold);
		}

		static DataGridView^ Grid(int x, int y, int w, int h)
		{
			DataGridView^ g = gcnew DataGridView();
			g->SetBounds(x, y, w, h);
			g->ReadOnly = true;
			g->AllowUserToAddRows = false;
			g->AllowUserToDeleteRows = false;
			g->AllowUserToResizeRows = false;
			g->SelectionMode = DataGridViewSelectionMode::FullRowSelect;
			g->MultiSelect = false;
			g->RowHeadersVisible = false;
			g->BackgroundColor = Color::White;
			g->BorderStyle = System::Windows::Forms::BorderStyle::None;
			g->CellBorderStyle = DataGridViewCellBorderStyle::SingleHorizontal;
			g->GridColor = Line;
			g->EnableHeadersVisualStyles = false;
			g->ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode::DisableResizing;
			g->ColumnHeadersHeight = 38;
			g->ColumnHeadersDefaultCellStyle->BackColor = Brand;
			g->ColumnHeadersDefaultCellStyle->ForeColor = Color::White;
			g->ColumnHeadersDefaultCellStyle->SelectionBackColor = Brand;
			g->ColumnHeadersDefaultCellStyle->Font = Face(9.5f, FontStyle::Bold);
			g->ColumnHeadersDefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleLeft;
			g->RowTemplate->Height = 32;
			g->DefaultCellStyle->Font = Face(9.5f, FontStyle::Regular);
			g->DefaultCellStyle->ForeColor = Ink;
			g->DefaultCellStyle->SelectionBackColor = Color::FromArgb(238, 208, 212);
			g->DefaultCellStyle->SelectionForeColor = Ink;
			g->AlternatingRowsDefaultCellStyle->BackColor = Color::FromArgb(252, 249, 247);
			g->AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode::AllCells;
			g->CellFormatting += gcnew DataGridViewCellFormattingEventHandler(&Theme::GridFormatting);
			return g;
		}

		static void Bind(DataGridView^ g, DataTable^ dt)
		{
			g->DataSource = dt;
			for each(DataGridViewColumn ^ c in g->Columns)
			{
				if (c->ValueType != nullptr && c->ValueType->Equals(DateTime::typeid))
					c->DefaultCellStyle->Format = L"yyyy-MM-dd";
			}
			g->ClearSelection();
		}

		// ---------------- combo helpers ----------------
		static void BindCombo(ComboBox^ cb, DataTable^ dt, String^ display, String^ value)
		{
			cb->DataSource = nullptr;
			cb->DisplayMember = display;
			cb->ValueMember = value;
			cb->DataSource = dt;
			if (dt->Rows->Count > 0) cb->SelectedIndex = 0;
			else cb->SelectedIndex = -1;
		}

		// inserts a "(not selected)" style row at the top; its value column is NULL
		static DataTable^ WithNone(DataTable^ dt, String^ valueCol, String^ labelCol, String^ text)
		{
			DataRow^ r = dt->NewRow();
			r[valueCol] = DBNull::Value;
			r[labelCol] = text;
			dt->Rows->InsertAt(r, 0);
			return dt;
		}

		static DataRow^ RowOf(ComboBox^ cb)
		{
			DataRowView^ v = dynamic_cast<DataRowView^>(cb->SelectedItem);
			if (v == nullptr) return nullptr;
			return v->Row;
		}

		// select the item whose column `col` equals `val` (string comparison)
		static void SelectBy(ComboBox^ cb, String^ col, Object^ val)
		{
			String^ want = Str(val);
			for (int i = 0; i < cb->Items->Count; i++)
			{
				DataRowView^ v = dynamic_cast<DataRowView^>(cb->Items[i]);
				if (v != nullptr && Str(v->Row[col]) == want)
				{
					cb->SelectedIndex = i;
					return;
				}
			}
		}
	};
}