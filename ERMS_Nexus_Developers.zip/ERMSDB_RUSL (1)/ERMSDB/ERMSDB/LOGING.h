#pragma once
#include "Theme.h"
#include "Db.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Login window.  Checks Employee ID + password against the Users table.
	//  On success the logged-in Session is available in Result.
	// ------------------------------------------------------------------
	public ref class LOGING : public Form
	{
	private:
		TextBox^ txtId;
		TextBox^ txtPw;
		CheckBox^ chkShow;
		Button^ btnLogin;
		Label^ lblErr;

	public:
		Session^ Result;

		LOGING()
		{
			Result = nullptr;
			this->Text = L"Sign in - Examination Report Monitoring System";
			this->ClientSize = System::Drawing::Size(1000, 620);
			this->StartPosition = FormStartPosition::CenterScreen;
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->BackColor = Color::White;
			this->Font = Theme::Face(9.0f, FontStyle::Regular);

			// layout: right panel (fill) + gold bar + hero (both docked left). Added in this order so the hero takes the left edge.
			Panel^ right = gcnew Panel();
			right->Dock = DockStyle::Fill;
			right->BackColor = Color::White;
			this->Controls->Add(right);

			Panel^ gold = gcnew Panel();
			gold->Dock = DockStyle::Left;
			gold->Width = 6;
			gold->BackColor = Theme::Gold;
			this->Controls->Add(gold);

			// ---------- left: hero image with university branding ----------
			PictureBox^ hero = gcnew PictureBox();
			hero->Dock = DockStyle::Left;
			hero->Width = 520;
			hero->BackColor = Theme::BrandDark;
			hero->SizeMode = PictureBoxSizeMode::StretchImage;
			Image^ campus = Theme::LoadImage(L"campus.jpg");      // optional: drop a real campus photo into the Images folder
			if (campus == nullptr) campus = Theme::LoadImage(L"login_hero.png");
			if (campus != nullptr) hero->Image = campus;
			this->Controls->Add(hero);

			Image^ crest = Theme::LoadImage(L"RUSL.png");
			if (crest != nullptr)
			{
				PictureBox^ pc = gcnew PictureBox();
				pc->SetBounds(36, 30, 70, 90);
				pc->Image = crest;
				pc->SizeMode = PictureBoxSizeMode::Zoom;
				pc->BackColor = Color::Transparent;
				hero->Controls->Add(pc);
			}
			hero->Controls->Add(Theme::Lbl(L"RAJARATA UNIVERSITY", 122, 44, 17.0f, FontStyle::Bold, Color::White));
			hero->Controls->Add(Theme::Lbl(L"OF SRI LANKA", 122, 74, 17.0f, FontStyle::Bold, Color::White));
			hero->Controls->Add(Theme::Lbl(L"Mihintale, Sri Lanka", 124, 106, 10.0f, FontStyle::Regular, Theme::Gold));

			hero->Controls->Add(Theme::Lbl(L"Examination Report", 36, 470, 24.0f, FontStyle::Bold, Color::White));
			hero->Controls->Add(Theme::Lbl(L"Monitoring System", 36, 508, 24.0f, FontStyle::Bold, Theme::Gold));
			hero->Controls->Add(Theme::Lbl(L"Track exam papers, packets and hand-overs in one place.", 38, 562, 10.0f, FontStyle::Regular, Color::White));

			// ---------- right: sign-in form (coordinates are relative to the right panel) ----------
			right->Controls->Add(Theme::Lbl(L"Welcome back", 70, 92, 26.0f, FontStyle::Bold, Theme::Brand));
			right->Controls->Add(Theme::Lbl(L"Sign in with your Employee ID and password.", 72, 144, 10.0f, FontStyle::Regular, Theme::Muted));

			right->Controls->Add(Theme::Lbl(L"EMPLOYEE ID", 72, 204, 9.0f, FontStyle::Bold, Theme::Muted));
			txtId = Theme::Txt(72, 228, 340);
			txtId->Font = Theme::Face(12.0f, FontStyle::Regular);
			txtId->MaxLength = 9;
			right->Controls->Add(txtId);

			right->Controls->Add(Theme::Lbl(L"PASSWORD", 72, 286, 9.0f, FontStyle::Bold, Theme::Muted));
			txtPw = Theme::Txt(72, 310, 340);
			txtPw->Font = Theme::Face(12.0f, FontStyle::Regular);
			txtPw->UseSystemPasswordChar = true;
			txtPw->MaxLength = 20;
			right->Controls->Add(txtPw);

			chkShow = gcnew CheckBox();
			chkShow->Text = L"Show password";
			chkShow->Location = System::Drawing::Point(72, 352);
			chkShow->AutoSize = true;
			chkShow->ForeColor = Theme::Muted;
			chkShow->CheckedChanged += gcnew EventHandler(this, &LOGING::DoShowPw);
			right->Controls->Add(chkShow);

			btnLogin = Theme::Btn(L"SIGN IN", 72, 392, 340, 48, 0);
			btnLogin->Font = Theme::Face(11.0f, FontStyle::Bold);
			btnLogin->Click += gcnew EventHandler(this, &LOGING::DoLogin);
			right->Controls->Add(btnLogin);
			this->AcceptButton = btnLogin;

			lblErr = Theme::Lbl(L"", 72, 452, 9.5f, FontStyle::Regular, Theme::Bad);
			lblErr->MaximumSize = System::Drawing::Size(340, 0);
			right->Controls->Add(lblErr);

			right->Controls->Add(Theme::Lbl(L"Trouble signing in? Please contact the AR Office.", 72, 560, 9.0f, FontStyle::Italic, Theme::Muted));
			txtId->Select();
		}

	private:
		void DoShowPw(Object^ sender, EventArgs^ e)
		{
			txtPw->UseSystemPasswordChar = !chkShow->Checked;
		}

		void DoLogin(Object^ sender, EventArgs^ e)
		{
			lblErr->Text = L"";
			int id = 0;
			if (!Int32::TryParse(txtId->Text->Trim(), id))
			{
				lblErr->Text = L"Please enter your numeric Employee ID.";
				txtId->Focus();
				return;
			}
			if (txtPw->Text->Length == 0)
			{
				lblErr->Text = L"Please enter your password.";
				txtPw->Focus();
				return;
			}

			btnLogin->Enabled = false;
			this->Cursor = Cursors::WaitCursor;
			try
			{
				Session^ s = Auth::Login(id, txtPw->Text);
				if (s == nullptr)
				{
					lblErr->Text = L"Invalid Employee ID or password.";
					txtPw->Clear();
					txtPw->Focus();
				}
				else
				{
					Result = s;
					this->DialogResult = System::Windows::Forms::DialogResult::OK;
					this->Close();
				}
			}
			catch (Exception^ ex)
			{
				lblErr->Text = L"Cannot reach the ERMS database. Check that MySQL is running and that the root password is correct.";
				MessageBox::Show(ex->Message, L"Database connection error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
			finally
			{
				this->Cursor = Cursors::Default;
				btnLogin->Enabled = true;
			}
		}
	};
}