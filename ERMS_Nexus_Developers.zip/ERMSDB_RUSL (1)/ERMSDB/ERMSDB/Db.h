#pragma once
// ============================================================================
//  Db.h  -  MySQL access layer, login/session handling
//  Edit ConnStr below if your MySQL server / user / password change.
// ============================================================================

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Collections::Generic;
	using namespace MySql::Data::MySqlClient;

	public ref class Db abstract sealed
	{
	public:
		// MySQL root password = 1234  (database name = ERMS)
		// If you get an authentication error with MySQL 8, append:  AllowPublicKeyRetrieval=true;
		// AllowUserVariables is needed so the audit triggers can see who is signed in (@erms_user)
		literal String^ ConnStr = L"Server=localhost;Port=3306;Database=ERMS;Uid=root;Pwd=1234;AllowUserVariables=True;";

		// Employee shown in the audit trail (set at sign-in)
		static String^ AuditUser;

	private:
		static void BindParams(MySqlCommand^ cmd, array<Object^>^ args)
		{
			if (args == nullptr) return;
			for (int i = 0; i + 1 < args->Length; i += 2)
			{
				String^ name = Convert::ToString(args[i]);
				Object^ val = args[i + 1];
				if (val == nullptr) val = DBNull::Value;
				cmd->Parameters->AddWithValue(name, val);
			}
		}

	public:
		static MySqlConnection^ Connect()
		{
			MySqlConnection^ cn = gcnew MySqlConnection(ConnStr);
			cn->Open();
			if (AuditUser != nullptr)
			{
				// tell the audit triggers who is working (SET @erms_user)
				MySqlCommand^ c = gcnew MySqlCommand(L"SET @erms_user = @u", cn);
				c->Parameters->AddWithValue(L"@u", AuditUser);
				c->ExecuteNonQuery();
			}
			return cn;
		}

		// Usage: Db::Query("SELECT ... WHERE a=@a AND b=@b", "@a", 1, "@b", "x");
		static DataTable^ Query(String^ sql, ... array<Object^>^ args)
		{
			MySqlConnection^ cn = Connect();
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand(sql, cn);
				BindParams(cmd, args);
				MySqlDataAdapter^ da = gcnew MySqlDataAdapter(cmd);
				DataTable^ dt = gcnew DataTable();
				da->Fill(dt);
				return dt;
			}
			finally
			{
				cn->Close();
			}
		}

		static int Exec(String^ sql, ... array<Object^>^ args)
		{
			MySqlConnection^ cn = Connect();
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand(sql, cn);
				BindParams(cmd, args);
				return cmd->ExecuteNonQuery();
			}
			finally
			{
				cn->Close();
			}
		}

		static Object^ Scalar(String^ sql, ... array<Object^>^ args)
		{
			MySqlConnection^ cn = Connect();
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand(sql, cn);
				BindParams(cmd, args);
				return cmd->ExecuteScalar();
			}
			finally
			{
				cn->Close();
			}
		}

		static int ScalarInt(String^ sql, ... array<Object^>^ args)
		{
			Object^ o = nullptr;
			MySqlConnection^ cn = Connect();
			try
			{
				MySqlCommand^ cmd = gcnew MySqlCommand(sql, cn);
				BindParams(cmd, args);
				o = cmd->ExecuteScalar();
			}
			finally
			{
				cn->Close();
			}
			if (o == nullptr || Convert::IsDBNull(o)) return 0;
			return Convert::ToInt32(o);
		}

		// Creates the tables of ERMS update 1 (payment sheets, extra exam documents) when they are missing,
		// and a demo HOD clerk login (Employee ID 19 / clerk123). Safe to run on every sign-in.
		static void EnsureSchema()
		{
			array<String^>^ sql = gcnew array<String^>{
				L"CREATE TABLE IF NOT EXISTS Exam_Document(`Year` INT NOT NULL, Semester_ID INT NOT NULL, Course_Code VARCHAR(10) NOT NULL, "
					L"Doc_Type VARCHAR(30) NOT NULL, Document_URL VARCHAR(200) NOT NULL, Submitted_By INT NOT NULL, Submitted_Date DATE NOT NULL, "
					L"PRIMARY KEY (`Year`, Semester_ID, Course_Code, Doc_Type), "
					L"FOREIGN KEY (`Year`, Semester_ID) REFERENCES Semester(`Year`, Semester_ID), "
					L"FOREIGN KEY (Course_Code) REFERENCES Course(Course_Code), "
					L"FOREIGN KEY (Submitted_By) REFERENCES Employee(Employee_ID))",

					L"CREATE TABLE IF NOT EXISTS Payment_Sheet(Sheet_ID INT AUTO_INCREMENT PRIMARY KEY, Employee_ID INT NOT NULL, "
					L"Sheet_URL VARCHAR(200) NOT NULL, Uploaded_Date DATE NOT NULL, `Status` VARCHAR(20) NOT NULL DEFAULT 'Uploaded', "
					L"Verified_By INT NULL, Verified_Date DATE NULL, Remarks VARCHAR(100) NULL, Forward_URL VARCHAR(200) NULL, "
					L"Forwarded_By INT NULL, Forwarded_Date DATE NULL, Paid_By INT NULL, Paid_Date DATE NULL, "
					L"FOREIGN KEY (Employee_ID) REFERENCES Employee(Employee_ID), FOREIGN KEY (Verified_By) REFERENCES Employee(Employee_ID), "
					L"FOREIGN KEY (Forwarded_By) REFERENCES Employee(Employee_ID), FOREIGN KEY (Paid_By) REFERENCES Employee(Employee_ID))",

					L"INSERT IGNORE INTO Employee (Employee_ID, First_Name, Last_Name, Adress_Line_1, Adress_Line_2, Email, Contact_Number) "
					L"VALUES (19, 'Kumari', 'Weerasinghe', 'No 30', 'Anuradhapura', 'kumari@uni.lk', '0730000000')",
					L"INSERT IGNORE INTO Employee_Qualification (Employee_ID, Qualification) "
					L"SELECT 19, 'Clerical Staff' FROM Employee WHERE Employee_ID = 19 AND Email = 'kumari@uni.lk'",
					L"INSERT IGNORE INTO `Admin` (Employee_ID, `Type`) SELECT 19, 'HOD Clerk' FROM Employee WHERE Employee_ID = 19 AND Email = 'kumari@uni.lk'",
					L"INSERT IGNORE INTO Users (Employee_ID, `Password`) SELECT 19, 'Clerk@2026' FROM Employee WHERE Employee_ID = 19 AND Email = 'kumari@uni.lk'"
			};
			for each (String ^ q in sql)
			{
				try { Exec(q); }
				catch (Exception^) {}
			}
		}

		// helper used by DbTx
		static void AddParams(MySqlCommand^ cmd, array<Object^>^ args) { BindParams(cmd, args); }
	};

	// ------------------------------------------------------------------
	//  Simple transaction wrapper:
	//    DbTx^ tx = gcnew DbTx();
	//    try { tx->Exec(...); tx->Exec(...); tx->Commit(); }
	//    catch (Exception^) { tx->Rollback(); throw; }
	// ------------------------------------------------------------------
	public ref class DbTx
	{
	private:
		MySqlConnection^ cn;
		MySqlTransaction^ tx;
	public:
		DbTx()
		{
			cn = Db::Connect();
			tx = cn->BeginTransaction();
		}

		int Exec(String^ sql, ... array<Object^>^ args)
		{
			MySqlCommand^ cmd = gcnew MySqlCommand(sql, cn, tx);
			Db::AddParams(cmd, args);
			return cmd->ExecuteNonQuery();
		}

		Object^ Scalar(String^ sql, ... array<Object^>^ args)
		{
			MySqlCommand^ cmd = gcnew MySqlCommand(sql, cn, tx);
			Db::AddParams(cmd, args);
			return cmd->ExecuteScalar();
		}

		void Commit()
		{
			tx->Commit();
			cn->Close();
		}

		void Rollback()
		{
			try { tx->Rollback(); }
			catch (Exception^) {}
			try { cn->Close(); }
			catch (Exception^) {}
		}
	};

	// ------------------------------------------------------------------
	//  Logged-in user
	// ------------------------------------------------------------------
	public ref class Session
	{
	public:
		int EmployeeId;
		String^ FirstName;
		String^ LastName;
		String^ Email;
		String^ Contact;
		String^ Qualification;
		String^ Role;     // current role: Dean | HOD | HOD Clerk | Lecturer in Charge | Second Examiner | Moderator | AR Office
		List<String^>^ Roles;   // every role this employee holds (can be switched in the main window)

		Session()
		{
			EmployeeId = 0;
			FirstName = L"";
			LastName = L"";
			Email = L"";
			Contact = L"";
			Qualification = L"";
			Role = L"";
			Roles = gcnew List<String^>();
		}

		String^ FullName() { return (FirstName + L" " + LastName)->Trim(); }

		String^ Initials()
		{
			String^ a = L"";
			String^ b = L"";
			if (FirstName->Length > 0) a = FirstName->Substring(0, 1);
			if (LastName->Length > 0) b = LastName->Substring(0, 1);
			return (a + b)->ToUpper();
		}
	};

	// ------------------------------------------------------------------
	//  Authentication + role resolution (uses the ERMS tables)
	// ------------------------------------------------------------------
	public ref class Auth abstract sealed
	{
	private:
		static bool InTable(String^ table, int id)
		{
			return Db::ScalarInt(L"SELECT COUNT(*) FROM " + table + L" WHERE Employee_ID = @id", L"@id", id) > 0;
		}

	public:
		// Filled by Login() when it returns nullptr: text to show the user, and whether the password must be changed
		static String^ LastMessage;
		static bool NeedsPasswordChange;

		// Changes the password (rules are enforced by the database: 8-20 chars, upper, lower, digit, special)
		static void ChangePassword(int id, String^ oldPw, String^ newPw)
		{
			Db::Exec(L"CALL Change_Password(@id, @o, @n)", L"@id", id, L"@o", oldPw, L"@n", newPw);
		}

		// All roles of an employee, in priority order. First entry = role used at sign-in.
		// An employee with a login but none of the roles is treated as AR Office.
		static List<String^>^ ResolveRoles(int id)
		{
			List<String^>^ roles = gcnew List<String^>();
			Object^ t = Db::Scalar(L"SELECT `Type` FROM `Admin` WHERE Employee_ID = @id", L"@id", id);
			String^ type = L"";
			if (t != nullptr && !Convert::IsDBNull(t)) type = t->ToString();

			if (type == L"Dean") roles->Add(L"Dean");
			if (type == L"HOD") roles->Add(L"HOD");
			if (InTable(L"Second_Examiner", id)) roles->Add(L"Second Examiner");
			if (InTable(L"Moderator", id)) roles->Add(L"Moderator");
			if (InTable(L"Lecturer_in_Charge", id)) roles->Add(L"Lecturer in Charge");
			if (type == L"HOD Clerk") roles->Add(L"HOD Clerk");
			if (roles->Count == 0) roles->Add(L"AR Office");
			return roles;
		}

		// Returns nullptr when the sign-in is refused (see LastMessage / NeedsPasswordChange).
		// Throws if the database cannot be reached.
		// Wrong passwords are counted by the database (procedure Login_Check): after 3 failures the account is locked.
		static Session^ Login(int id, String^ password)
		{
			LastMessage = L"";
			NeedsPasswordChange = false;
			Db::EnsureSchema();

			DataTable^ chk = Db::Query(L"CALL Login_Check(@id, @pw)", L"@id", id, L"@pw", password);
			String^ st = L"BAD";
			int detail = 0;
			if (chk->Rows->Count > 0)
			{
				st = Convert::ToString(chk->Rows[0][L"Status"]);
				detail = Convert::ToInt32(chk->Rows[0][L"Detail"]);
			}

			if (st == L"LOCKED")
			{
				LastMessage = L"This account is locked for " + detail.ToString() + L" more minute(s) because of too many wrong passwords.";
				return nullptr;
			}
			if (st == L"EXPIRED")
			{
				NeedsPasswordChange = true;
				LastMessage = L"Your password has expired. Please choose a new one.";
				return nullptr;
			}
			if (st != L"OK")
			{
				LastMessage = L"Invalid Employee ID or password.";
				if (detail > 0) LastMessage = LastMessage + L" " + detail.ToString() + L" attempt(s) left before the account is locked.";
				return nullptr;
			}

			DataTable^ dt = Db::Query(
				L"SELECT e.First_Name, e.Last_Name, e.Email, e.Contact_Number FROM Employee e WHERE e.Employee_ID = @id", L"@id", id);
			if (dt->Rows->Count == 0) return nullptr;
			DataRow^ r = dt->Rows[0];

			Session^ s = gcnew Session();
			s->EmployeeId = id;
			s->FirstName = Convert::ToString(r[L"First_Name"]);
			s->LastName = Convert::ToString(r[L"Last_Name"]);
			s->Email = Convert::ToString(r[L"Email"]);
			s->Contact = Convert::ToString(r[L"Contact_Number"]);

			Object^ q = Db::Scalar(
				L"SELECT GROUP_CONCAT(Qualification SEPARATOR ', ') FROM Employee_Qualification WHERE Employee_ID = @id",
				L"@id", id);
			if (q != nullptr && !Convert::IsDBNull(q)) s->Qualification = q->ToString();

			// one login = one interface: the highest-priority role only (no mixing of role screens)
			List<String^>^ all = ResolveRoles(id);
			s->Role = all[0];
			s->Roles->Add(s->Role);
			Db::AuditUser = L"Employee " + id.ToString() + L" (" + s->Role + L")";   // shown in the audit trail
			return s;
		}
	};

	// ------------------------------------------------------------------
	//  Shared SQL fragments
	// ------------------------------------------------------------------
	public ref class Sql abstract sealed
	{
	public:
		// One row per (Year, Semester, Course) that exists in Exam_Offering or Exam_Packet_Tracking
		static String^ TrackingSelect()
		{
			return
				L"SELECT k.`Year` AS `Year`, k.Semester_ID AS `Sem`, k.Course_Code AS `Course Code`, c.Name AS `Course Name`, "
				L"o.Exam_Date AS `Exam Date`, o.Answer_Script_Count AS `Scripts`, o.`Status` AS `Status`, "
				L"p.Packet_Submission_Date AS `Packet Submitted`, p.EIS_Update_Date AS `EIS Update`, "
				L"p.Handover_Date AS `Handover`, p.Packet_Count AS `Packets`, p.Document_URL AS `Document URL`, "
				L"CASE WHEN p.Handover_Date IS NOT NULL THEN 'Handed over' "
				L"WHEN p.EIS_Update_Date IS NOT NULL THEN 'EIS updated' "
				L"WHEN p.Packet_Submission_Date IS NOT NULL THEN 'Packet submitted' "
				L"ELSE 'Pending' END AS `Stage` "
				L"FROM (SELECT `Year`, Semester_ID, Course_Code FROM Exam_Offering "
				L"UNION SELECT `Year`, Semester_ID, Course_Code FROM Exam_Packet_Tracking) k "
				L"JOIN Course c ON c.Course_Code = k.Course_Code "
				L"LEFT JOIN Exam_Offering o ON o.`Year` = k.`Year` AND o.Semester_ID = k.Semester_ID AND o.Course_Code = k.Course_Code "
				L"LEFT JOIN Exam_Packet_Tracking p ON p.`Year` = k.`Year` AND p.Semester_ID = k.Semester_ID AND p.Course_Code = k.Course_Code ";
		}

		// Restrict tracking rows to courses assigned to @emp with a Transaction_Type starting with @tt
		static String^ AssignedFilter()
		{
			return
				L"WHERE EXISTS (SELECT 1 FROM Admin_Course ac WHERE ac.Employee_ID = @emp "
				L"AND ac.`Year` = k.`Year` AND ac.Semester_ID = k.Semester_ID AND ac.Course_Code = k.Course_Code "
				L"AND ac.Transaction_Type LIKE @tt) ";
		}

		static String^ TrackingOrder()
		{
			return L" ORDER BY k.`Year` DESC, k.Semester_ID DESC, k.Course_Code";
		}

		// Academic grade ranking (higher number = higher grade)
		//   1 Temporary Lecturer < 2 Probationary Lecturer < 3 Temporary Senior Lecturer
		//   < 4 Senior Lecturer Grade 2 < 5 Senior Lecturer Grade 1 < 6 Professor
		// SQL expression: highest grade of the employee whose id is given by idExpr (e.g. "@x" or "e.Employee_ID"); 0 = unknown grade
		static String^ RankOf(String^ idExpr)
		{
			return L"IFNULL((SELECT MAX(CASE q.Qualification "
				L"WHEN 'Temporary Lecturer' THEN 1 WHEN 'Probationary Lecturer' THEN 2 WHEN 'Temporary Senior Lecturer' THEN 3 "
				L"WHEN 'Senior Lecturer Grade 2' THEN 4 WHEN 'Senior Lecturer Grade 1' THEN 5 WHEN 'Professor' THEN 6 ELSE 0 END) "
				L"FROM Employee_Qualification q WHERE q.Employee_ID = " + idExpr + L"), 0)";
		}

		static array<String^>^ GradeNames()
		{
			return gcnew array<String^>{ L"Temporary Lecturer", L"Probationary Lecturer", L"Temporary Senior Lecturer",
				L"Senior Lecturer Grade 2", L"Senior Lecturer Grade 1", L"Professor" };
		}

		// payment sheets with lecturer name; append a WHERE / ORDER BY
		static String^ PaymentSelect()
		{
			return
				L"SELECT p.Sheet_ID AS `ID`, p.Employee_ID AS `Lecturer ID`, CONCAT(e.First_Name, ' ', e.Last_Name) AS `Lecturer`, "
				L"p.Uploaded_Date AS `Uploaded`, p.`Status` AS `Status`, p.Verified_Date AS `Verified`, "
				L"p.Forwarded_Date AS `Sent to AR`, p.Paid_Date AS `Paid`, p.Sheet_URL AS `Sheet URL`, "
				L"IFNULL(p.Forward_URL, '') AS `AR Sheet URL`, IFNULL(p.Remarks, '') AS `Remarks` "
				L"FROM Payment_Sheet p JOIN Employee e ON e.Employee_ID = p.Employee_ID ";
		}

		static String^ SemesterList()
		{
			return L"SELECT `Year`, Semester_ID, CONCAT(`Year`, ' - Semester ', Semester_ID) AS Label, CONCAT(`Year`, '-', Semester_ID) AS K "
				L"FROM Semester ORDER BY `Year` DESC, Semester_ID DESC";
		}

		static String^ CourseList()
		{
			return L"SELECT Course_Code, CONCAT(Course_Code, ' - ', Name) AS Label FROM Course ORDER BY Course_Code";
		}
	};
}