#pragma once
#include "BasePage.h"
#include "LecturerDashBord.h"
#include "docup.h"
#include "TrakingDetails.h"
#include "secondExaminer.h"
#include "secondExaminerTraking.h"
#include "ModaretorDashBord.h"
#include "HODDashBord.h"
#include "HODDocument.h"
#include "HODTraking.h"
#include "DEANDASHBORD1.h"
#include "DEANTRAKING.h"
#include "AROFFICE.h"
#include "secondExaminerDocument.h"
#include "PaymentSheetUpload.h"
#include "HODPayment.h"
#include "HODclark.h"
#include "ARPayment.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;
	using namespace System::Collections::Generic;

	// ------------------------------------------------------------------
	//  Main window: RUSL header, role based side menu, page area, footer
	// ------------------------------------------------------------------
	public ref class MainShell : public Form
	{
	private:
		Session^ S;
		Panel^ sidebar;
		Panel^ content;
		List<Button^>^ navButtons;
		array<BasePage^>^ pages;
		int current;

	public:
		bool LoggedOut;
		bool SwitchRequested;

		MainShell(Session^ s)
		{
			S = s;
			LoggedOut = false;
			SwitchRequested = false;
			current = -1;
			navButtons = gcnew List<Button^>();

			this->Text = L"Examination Report Monitoring System - Rajarata University of Sri Lanka";
			this->StartPosition = FormStartPosition::CenterScreen;
			this->ClientSize = System::Drawing::Size(1280, 780);
			this->MinimumSize = System::Drawing::Size(1180, 720);
			this->BackColor = Theme::Bg;
			this->Font = Theme::Face(9.0f, FontStyle::Regular);

			content = gcnew Panel();
			content->Dock = DockStyle::Fill;
			content->BackColor = Theme::Bg;
			this->Controls->Add(content);

			BuildSidebar();
			BuildFooter();
			BuildHeader();

			this->Load += gcnew EventHandler(this, &MainShell::DoLoad);
		}

	private:
		// ---------------- layout ----------------
		void BuildHeader()
		{
			Panel^ header = gcnew Panel();
			header->Dock = DockStyle::Top;
			header->Height = 78;
			header->BackColor = Theme::BrandDark;
			Image^ bg = Theme::LoadImage(L"header_banner.png");
			if (bg != nullptr)
			{
				header->BackgroundImage = bg;
				header->BackgroundImageLayout = ImageLayout::Stretch;
			}

			Image^ mini = Theme::LoadImage(L"RUSLMiniLogo.png");
			int tx = 24;
			if (mini != nullptr)
			{
				PictureBox^ pb = gcnew PictureBox();
				pb->SetBounds(18, 7, 54, 64);
				pb->Image = mini;
				pb->SizeMode = PictureBoxSizeMode::Zoom;
				pb->BackColor = Color::Transparent;
				header->Controls->Add(pb);
				tx = 84;
			}
			header->Controls->Add(Theme::Lbl(L"RAJARATA UNIVERSITY OF SRI LANKA", tx, 12, 16.0f, FontStyle::Bold, Color::White));
			header->Controls->Add(Theme::Lbl(L"Examination Report Monitoring System", tx + 2, 44, 10.5f, FontStyle::Regular, Theme::Gold));

			// user chip on the right
			Label^ nm = Theme::Lbl(S->FullName(), 0, 16, 11.0f, FontStyle::Bold, Color::White);
			Label^ rl = Theme::Lbl(S->Role + L"  |  ID " + S->EmployeeId.ToString(), 0, 42, 9.0f, FontStyle::Regular, Theme::Gold);
			nm->Anchor = AnchorStyles::Top | AnchorStyles::Right;
			rl->Anchor = AnchorStyles::Top | AnchorStyles::Right;
			int w = (nm->PreferredWidth > rl->PreferredWidth) ? nm->PreferredWidth : rl->PreferredWidth;
			int x = this->ClientSize.Width - w - 76;
			nm->Left = x;
			rl->Left = x;
			header->Controls->Add(nm);
			header->Controls->Add(rl);

			Label^ av = gcnew Label();
			av->SetBounds(this->ClientSize.Width - 62, 18, 42, 42);
			av->Anchor = AnchorStyles::Top | AnchorStyles::Right;
			av->BackColor = Theme::Gold;
			av->ForeColor = Theme::BrandDark;
			av->Font = Theme::Face(12.0f, FontStyle::Bold);
			av->TextAlign = ContentAlignment::MiddleCenter;
			av->Text = S->Initials();
			System::Drawing::Drawing2D::GraphicsPath^ gp = gcnew System::Drawing::Drawing2D::GraphicsPath();
			gp->AddEllipse(0, 0, 42, 42);
			av->Region = gcnew System::Drawing::Region(gp);
			header->Controls->Add(av);

			this->Controls->Add(header);
		}

		void BuildFooter()
		{
			Panel^ footer = gcnew Panel();
			footer->Dock = DockStyle::Bottom;
			footer->Height = 28;
			footer->BackColor = Color::White;
			footer->Controls->Add(Theme::Lbl(L"\u00A9 " + DateTime::Now.Year.ToString() + L" Rajarata University of Sri Lanka  \u00B7  Mihintale", 252, 6, 8.5f, FontStyle::Regular, Theme::Muted));
			Label^ db = Theme::Lbl(L"\u25CF Connected to ERMS database", 0, 6, 8.5f, FontStyle::Regular, Theme::Good);
			db->Anchor = AnchorStyles::Top | AnchorStyles::Right;
			db->Left = this->ClientSize.Width - db->PreferredWidth - 20;
			footer->Controls->Add(db);
			this->Controls->Add(footer);
		}

		void BuildSidebar()
		{
			sidebar = gcnew Panel();
			sidebar->Dock = DockStyle::Left;
			sidebar->Width = 232;
			sidebar->BackColor = Theme::BrandDark;
			Image^ tex = Theme::LoadImage(L"sidebar_texture.png");
			if (tex != nullptr)
			{
				sidebar->BackgroundImage = tex;
				sidebar->BackgroundImageLayout = ImageLayout::Stretch;
			}

			Image^ crest = Theme::LoadImage(L"RUSL.png");
			if (crest != nullptr)
			{
				PictureBox^ pb = gcnew PictureBox();
				pb->SetBounds(66, 18, 100, 128);
				pb->Image = crest;
				pb->SizeMode = PictureBoxSizeMode::Zoom;
				pb->BackColor = Color::Transparent;
				sidebar->Controls->Add(pb);
			}

			Label^ role = gcnew Label();
			role->SetBounds(0, 152, 232, 22);
			role->TextAlign = ContentAlignment::MiddleCenter;
			role->Font = Theme::Face(9.5f, FontStyle::Bold);
			role->ForeColor = Theme::Gold;
			role->BackColor = Color::Transparent;
			role->Text = S->Role->ToUpper();
			sidebar->Controls->Add(role);

			Panel^ sep = gcnew Panel();
			sep->SetBounds(24, 182, 184, 1);
			sep->BackColor = Theme::Gold;
			sidebar->Controls->Add(sep);

			array<String^>^ titles = nullptr;
			array<String^>^ glyphs = nullptr;
			if (S->Role == L"Lecturer in Charge")
			{
				titles = gcnew array<String^>{ L"Dashboard", L"Document Submission", L"Tracking", L"Payment Sheet" };
				glyphs = gcnew array<String^>{ L"\uE80F", L"\uE8A5", L"\uE81C", L"\uE73E" };
			}
			else if (S->Role == L"Second Examiner")
			{
				titles = gcnew array<String^>{ L"View", L"Document Submission", L"Tracking", L"Payment Sheet" };
				glyphs = gcnew array<String^>{ L"\uE80F", L"\uE8A5", L"\uE81C", L"\uE73E" };
			}
			else if (S->Role == L"Moderator")
			{
				titles = gcnew array<String^>{ L"Dashboard & Verify", L"Payment Sheet" };
				glyphs = gcnew array<String^>{ L"\uE80F", L"\uE73E" };
			}
			else if (S->Role == L"HOD")
			{
				titles = gcnew array<String^>{ L"Dashboard", L"Course Tracking", L"Employees", L"Payment Sheets" };
				glyphs = gcnew array<String^>{ L"\uE80F", L"\uE8A5", L"\uE716", L"\uE73E" };
			}
			else if (S->Role == L"HOD Clerk")
			{
				titles = gcnew array<String^>{ L"View Payment Sheets" };
				glyphs = gcnew array<String^>{ L"\uE73E" };
			}
			else if (S->Role == L"Dean")
			{
				titles = gcnew array<String^>{ L"Dashboard", L"Employees" };
				glyphs = gcnew array<String^>{ L"\uE80F", L"\uE716" };
			}
			else
			{
				titles = gcnew array<String^>{ L"Exam Packets", L"Payment Sheets" };
				glyphs = gcnew array<String^>{ L"\uE80F", L"\uE73E" };
			}

			pages = gcnew array<BasePage^>(titles->Length);
			for (int i = 0; i < titles->Length; i++)
			{
				Button^ b = gcnew Button();
				b->SetBounds(0, 196 + i * 50, 232, 48);
				b->FlatStyle = FlatStyle::Flat;
				b->FlatAppearance->BorderSize = 0;
				b->FlatAppearance->MouseOverBackColor = Color::FromArgb(110, 14, 28);
				b->FlatAppearance->MouseDownBackColor = Color::FromArgb(140, 20, 36);
				b->BackColor = Color::Transparent;
				b->ForeColor = Color::White;
				b->Font = Theme::Face(10.5f, FontStyle::Regular);
				b->Cursor = Cursors::Hand;
				b->TextAlign = ContentAlignment::MiddleLeft;
				b->ImageAlign = ContentAlignment::MiddleLeft;
				b->TextImageRelation = TextImageRelation::ImageBeforeText;
				b->Padding = System::Windows::Forms::Padding(22, 0, 0, 0);
				b->Image = Theme::Glyph(glyphs[i], 22, Color::White);
				b->Text = L"   " + titles[i];
				b->Tag = i;
				b->Click += gcnew EventHandler(this, &MainShell::DoNav);
				sidebar->Controls->Add(b);
				navButtons->Add(b);
			}

			if (S->Roles->Count > 1)
			{
				Button^ sw = gcnew Button();
				sw->Dock = DockStyle::Bottom;
				sw->Height = 48;
				sw->FlatStyle = FlatStyle::Flat;
				sw->FlatAppearance->BorderSize = 0;
				sw->FlatAppearance->MouseOverBackColor = Color::FromArgb(110, 14, 28);
				sw->BackColor = Color::FromArgb(70, 6, 18);
				sw->ForeColor = Color::White;
				sw->Font = Theme::Face(10.0f, FontStyle::Regular);
				sw->Cursor = Cursors::Hand;
				sw->TextAlign = ContentAlignment::MiddleLeft;
				sw->ImageAlign = ContentAlignment::MiddleLeft;
				sw->TextImageRelation = TextImageRelation::ImageBeforeText;
				sw->Padding = System::Windows::Forms::Padding(22, 0, 0, 0);
				sw->Image = Theme::Glyph(L"\uE716", 20, Color::White);
				sw->Text = L"   Switch Role";
				sw->Click += gcnew EventHandler(this, &MainShell::DoSwitchMenu);
				sidebar->Controls->Add(sw);
			}

			Button^ lo = gcnew Button();
			lo->Dock = DockStyle::Bottom;
			lo->Height = 52;
			lo->FlatStyle = FlatStyle::Flat;
			lo->FlatAppearance->BorderSize = 0;
			lo->FlatAppearance->MouseOverBackColor = Color::FromArgb(110, 14, 28);
			lo->BackColor = Color::FromArgb(44, 0, 8);
			lo->ForeColor = Theme::Gold;
			lo->Font = Theme::Face(10.5f, FontStyle::Bold);
			lo->Cursor = Cursors::Hand;
			lo->TextAlign = ContentAlignment::MiddleLeft;
			lo->ImageAlign = ContentAlignment::MiddleLeft;
			lo->TextImageRelation = TextImageRelation::ImageBeforeText;
			lo->Padding = System::Windows::Forms::Padding(22, 0, 0, 0);
			lo->Image = Theme::Glyph(L"\uE7E8", 22, Theme::Gold);
			lo->Text = L"   Log Out";
			lo->Click += gcnew EventHandler(this, &MainShell::DoLogout);
			sidebar->Controls->Add(lo);

			this->Controls->Add(sidebar);
		}

		// ---------------- pages ----------------
		BasePage^ MakePage(int i)
		{
			if (S->Role == L"Lecturer in Charge")
			{
				if (i == 0) return gcnew LecturerDashBord(S);
				if (i == 1) return gcnew docup(S);
				if (i == 2) return gcnew TrakingDetails(S);
				return gcnew PaymentSheetUpload(S);
			}
			if (S->Role == L"Second Examiner")
			{
				if (i == 0) return gcnew secondExaminer(S);
				if (i == 1) return gcnew secondExaminerDocument(S);
				if (i == 2) return gcnew secondExaminerTraking(S);
				return gcnew PaymentSheetUpload(S);
			}
			if (S->Role == L"Moderator")
			{
				if (i == 0) return gcnew ModaretorDashBord(S);
				return gcnew PaymentSheetUpload(S);
			}
			if (S->Role == L"HOD")
			{
				if (i == 0) return gcnew HODDashBord(S);
				if (i == 1) return gcnew HODDocument(S);
				if (i == 2) return gcnew HODTraking(S);
				return gcnew HODPayment(S);
			}
			if (S->Role == L"HOD Clerk") return gcnew HODclark(S);
			if (S->Role == L"Dean")
			{
				if (i == 0) return gcnew DEANDASHBORD(S);
				return gcnew DEANTRAKING(S);
			}
			if (i == 0) return gcnew AROFFICE(S);
			return gcnew ARPayment(S);
		}

		void ShowPage(int i)
		{
			if (i < 0 || i >= pages->Length) return;
			if (current >= 0 && pages[current] != nullptr) pages[current]->Visible = false;

			if (pages[i] == nullptr)
			{
				pages[i] = MakePage(i);
				content->Controls->Add(pages[i]);
			}
			current = i;
			for (int k = 0; k < navButtons->Count; k++)
			{
				bool on = (k == i);
				navButtons[k]->BackColor = on ? Color::FromArgb(150, 28, 46) : Color::Transparent;
				navButtons[k]->Font = Theme::Face(10.5f, on ? FontStyle::Bold : FontStyle::Regular);
			}
			pages[i]->Visible = true;
			pages[i]->BringToFront();
			pages[i]->Reload();
		}

		void DoLoad(Object^ sender, EventArgs^ e)
		{
			ShowPage(0);
		}

		void DoNav(Object^ sender, EventArgs^ e)
		{
			Button^ b = safe_cast<Button^>(sender);
			ShowPage(Convert::ToInt32(b->Tag));
		}

		void DoSwitchMenu(Object^ sender, EventArgs^ e)
		{
			System::Windows::Forms::ContextMenuStrip^ m = gcnew System::Windows::Forms::ContextMenuStrip();
			m->Font = Theme::Face(10.0f, FontStyle::Regular);
			for each(String ^ r in S->Roles)
			{
				if (r != S->Role) m->Items->Add(r, nullptr, gcnew EventHandler(this, &MainShell::DoSwitchTo));
			}
			m->Show(System::Windows::Forms::Cursor::Position);
		}

		void DoSwitchTo(Object^ sender, EventArgs^ e)
		{
			ToolStripItem^ it = safe_cast<ToolStripItem^>(sender);
			S->Role = it->Text;
			SwitchRequested = true;
			this->Close();
		}

		void DoLogout(Object^ sender, EventArgs^ e)
		{
			LoggedOut = true;
			this->Close();
		}
	};
}