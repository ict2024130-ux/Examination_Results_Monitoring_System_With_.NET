#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Diagnostics;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Second Examiner dashboard (profile + assigned courses + document link).
	//  The Moderator dashboard (ModaretorDashBord) derives from this class and
	//  additionally allows "Mark as Verified".
	// ------------------------------------------------------------------
	public ref class secondExaminer : public BasePage
	{
	private:
		String^ roleLike;     // 'Second Examiner%' or 'Moderator%'
		String^ roleBase;     // 'Second Examiner' or 'Moderator'
		bool canVerify;
		DataGridView^ grid;
		Panel^ kpiAssigned;
		Panel^ kpiSecond;

	public:
		secondExaminer(Session^ s)
			: BasePage(s, L"Second Examiner Dashboard", L"Courses where you act as second examiner.")
		{
			roleLike = L"Second Examiner%";
			roleBase = L"Second Examiner";
			canVerify = false;
			Build();
		}

	protected:
		secondExaminer(Session^ s, String^ title, String^ subtitle, String^ like, String^ baseName, bool verify)
			: BasePage(s, title, subtitle)
		{
			roleLike = like;
			roleBase = baseName;
			canVerify = verify;
			Build();
		}

	public:
		virtual void Reload() override
		{
			try
			{
				String^ verifyCol = L"";
				if (canVerify)
					verifyCol = L"IF(ac.Transaction_Type LIKE '%Verified', 'Verified', 'Pending verification') AS `Verification`, ";

				DataTable^ dt = Db::Query(
					L"SELECT ac.`Year` AS `Year`, ac.Semester_ID AS `Sem`, ac.Course_Code AS `Course Code`, c.Name AS `Course Name`, "
					L"(SELECT GROUP_CONCAT(CONCAT(e2.First_Name, ' ', e2.Last_Name) SEPARATOR ', ') FROM Admin_Course a2 "
					L"JOIN Employee e2 ON e2.Employee_ID = a2.Employee_ID WHERE a2.`Year` = ac.`Year` AND a2.Semester_ID = ac.Semester_ID "
					L"AND a2.Course_Code = ac.Course_Code AND a2.Transaction_Type LIKE 'Lecturer in Charge%') AS `Lecturer in Charge`, "
					L"o.Exam_Date AS `Exam Date`, " + verifyCol +
					L"p.Document_URL AS `Document URL` "
					L"FROM Admin_Course ac JOIN Course c ON c.Course_Code = ac.Course_Code "
					L"LEFT JOIN Exam_Offering o ON o.`Year` = ac.`Year` AND o.Semester_ID = ac.Semester_ID AND o.Course_Code = ac.Course_Code "
					L"LEFT JOIN Exam_Packet_Tracking p ON p.`Year` = ac.`Year` AND p.Semester_ID = ac.Semester_ID AND p.Course_Code = ac.Course_Code "
					L"WHERE ac.Employee_ID = @e AND ac.Transaction_Type LIKE @tt "
					L"ORDER BY ac.`Year` DESC, ac.Semester_ID DESC, ac.Course_Code",
					L"@e", S->EmployeeId, L"@tt", roleLike);
				Theme::Bind(grid, dt);

				Theme::SetKpi(kpiAssigned, dt->Rows->Count.ToString());
				int n = 0;
				for each (DataRow^ r in dt->Rows)
				{
					if (canVerify)
					{
						if (Theme::Str(r[L"Verification"]) == L"Verified") n++;
					}
					else
					{
						if (Theme::Str(r[L"Document URL"])->Length > 0) n++;
					}
				}
				Theme::SetKpi(kpiSecond, n.ToString());
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			Panel^ banner = WelcomeBanner(28, 92, 900);
			StretchX(banner);
			this->Controls->Add(banner);

			this->Controls->Add(ProfileCard(28, 178, 380));

			String^ cap2 = canVerify ? L"VERIFIED DOCUMENTS" : L"DOCUMENTS AVAILABLE";
			kpiAssigned = Theme::Kpi(428, 178, 250, 84, L"ASSIGNED COURSES", L"0", Theme::Brand);
			kpiSecond = Theme::Kpi(694, 178, 250, 84, cap2, L"0", Theme::Good);
			this->Controls->Add(kpiAssigned);
			this->Controls->Add(kpiSecond);

			Panel^ info = Theme::Card(428, 278, 516, 136, L"How it works");
			if (canVerify)
			{
				info->Controls->Add(Theme::Lbl(L"1.  Select a course below and open its document link.", 20, 52, 9.5f, FontStyle::Regular, Theme::Ink));
				info->Controls->Add(Theme::Lbl(L"2.  Review the paper and marking scheme.", 20, 76, 9.5f, FontStyle::Regular, Theme::Ink));
				info->Controls->Add(Theme::Lbl(L"3.  Press \"Mark as Verified\" to record your approval.", 20, 100, 9.5f, FontStyle::Regular, Theme::Ink));
			}
			else
			{
				info->Controls->Add(Theme::Lbl(L"1.  The lecturer in charge nominates you for a course.", 20, 52, 9.5f, FontStyle::Regular, Theme::Ink));
				info->Controls->Add(Theme::Lbl(L"2.  Select a course below and open its document link.", 20, 76, 9.5f, FontStyle::Regular, Theme::Ink));
				info->Controls->Add(Theme::Lbl(L"3.  Follow packet progress on the Tracking screen.", 20, 100, 9.5f, FontStyle::Regular, Theme::Ink));
			}
			this->Controls->Add(info);

			Panel^ gc = Theme::Card(28, 434, 916, 330, L"Assigned Courses");
			grid = Theme::Grid(20, 54, 876, 200);
			gc->Controls->Add(grid);

			Button^ btnOpen = Theme::Btn(L"Open Document", 20, 268, 170, 40, 1);
			btnOpen->Click += gcnew EventHandler(this, &secondExaminer::DoOpen);
			gc->Controls->Add(btnOpen);

			if (canVerify)
			{
				Button^ btnVerify = Theme::Btn(L"Mark as Verified", 204, 268, 180, 40, 0);
				btnVerify->Click += gcnew EventHandler(this, &secondExaminer::DoVerify);
				gc->Controls->Add(btnVerify);
			}
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);
			SetScrollHeight(790);
		}

		void DoOpen(Object^ sender, EventArgs^ e)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Select a course in the table first.");
				return;
			}
			String^ u = Theme::Str(r->Cells[L"Document URL"]->Value);
			Uri^ uri = nullptr;
			if (u->Length == 0 || !Uri::TryCreate(u, UriKind::Absolute, uri) || (uri->Scheme != L"http" && uri->Scheme != L"https"))
			{
				Theme::MsgWarn(L"The lecturer has not submitted a valid document link for this course yet.");
				return;
			}
			try { Process::Start(u); }
			catch (Exception^ ex) { Theme::Fail(ex); }
		}

		void DoVerify(Object^ sender, EventArgs^ e)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Select a course in the table first.");
				return;
			}
			if (Theme::Str(r->Cells[L"Document URL"]->Value)->Length == 0)
			{
				Theme::MsgWarn(L"There is no document to verify for this course yet.");
				return;
			}
			if (Theme::Str(r->Cells[L"Verification"]->Value) == L"Verified")
			{
				Theme::MsgInfo(L"This course is already verified.");
				return;
			}
			String^ code = Convert::ToString(r->Cells[L"Course Code"]->Value);
			if (!Theme::Confirm(L"Mark the document of " + code + L" as verified?")) return;
			try
			{
				Db::Exec(
					L"UPDATE Admin_Course SET Transaction_Type = 'Moderator - Verified' "
					L"WHERE Employee_ID = @e AND `Year` = @y AND Semester_ID = @s AND Course_Code = @c AND Transaction_Type LIKE 'Moderator%'",
					L"@e", S->EmployeeId, L"@y", Convert::ToInt32(r->Cells[L"Year"]->Value),
					L"@s", Convert::ToInt32(r->Cells[L"Sem"]->Value), L"@c", code);
				Reload();
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}
