#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  HOD Clerk  -  takes the payment sheets verified by the HOD and
	//                submits them to the AR office (Status: Verified -> Sent to AR)
	// ------------------------------------------------------------------
	public ref class HODclark : public BasePage
	{
	private:
		DataGridView^ grid;
		TextBox^ txtUrl;
		TextBox^ txtLecturer;
		DateTimePicker^ dtpDate;
		Panel^ kWait;
		Panel^ kSent;
		Panel^ kPaid;

	public:
		HODclark(Session^ s)
			: BasePage(s, L"HOD Clerk - Payment Sheets", L"Send the sheets verified by the HOD to the AR office for payment.")
		{
			Build();
		}

		virtual void Reload() override
		{
			LoadGrid();
		}

	private:
		void Build()
		{
			kWait = Theme::Kpi(28, 92, 220, 84, L"VERIFIED - TO SEND", L"0", Theme::Good);
			kSent = Theme::Kpi(264, 92, 220, 84, L"SENT TO AR OFFICE", L"0", Theme::Info);
			kPaid = Theme::Kpi(500, 92, 220, 84, L"PAID", L"0", Theme::Brand);
			this->Controls->Add(kWait);
			this->Controls->Add(kSent);
			this->Controls->Add(kPaid);

			Panel^ gc = Theme::Card(28, 196, 928, 300, L"Verified Payment Sheets");
			grid = Theme::Grid(20, 54, 888, 226);
			grid->SelectionChanged += gcnew EventHandler(this, &HODclark::DoSelected);
			gc->Controls->Add(grid);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);

			Panel^ fc = Theme::Card(28, 516, 640, 310, L"Send Payment Sheet to AR Office");
			txtUrl = Theme::Txt(0, 0, 100);
			txtUrl->MaxLength = 200;
			txtLecturer = Theme::Txt(0, 0, 100);
			txtLecturer->MaxLength = 9;
			dtpDate = Theme::DatePick(0, 0, 100, false);
			Theme::Field(fc, L"Payment sheet URL", txtUrl, 58);
			Theme::Field(fc, L"Lecturer (Employee ID)", txtLecturer, 102);
			Theme::Field(fc, L"Submission date", dtpDate, 146);
			fc->Controls->Add(Theme::Lbl(L"Select a verified sheet in the table - the form fills in automatically.", 20, 192, 9.0f, FontStyle::Italic, Theme::Muted));
			Button^ bSend = Theme::Btn(L"Submit to AR Office", 160, 230, 210, 42, 0);
			Button^ bOpen = Theme::Btn(L"Open Sheet", 382, 230, 150, 42, 1);
			bSend->Click += gcnew EventHandler(this, &HODclark::DoSend);
			bOpen->Click += gcnew EventHandler(this, &HODclark::DoOpen);
			fc->Controls->Add(bSend);
			fc->Controls->Add(bOpen);
			this->Controls->Add(fc);

			SetScrollHeight(850);
		}

		void LoadGrid()
		{
			try
			{
				DataTable^ dt = Db::Query(Sql::PaymentSelect() +
					L"WHERE p.`Status` IN ('Verified', 'Sent to AR', 'Paid') "
					L"ORDER BY FIELD(p.`Status`, 'Verified', 'Sent to AR', 'Paid'), p.Sheet_ID DESC");
				Theme::Bind(grid, dt);
				if (grid->Columns->Contains(L"AR Sheet URL")) grid->Columns[L"AR Sheet URL"]->Visible = false;
				int w = 0, s = 0, p = 0;
				for each (DataRow^ r in dt->Rows)
				{
					String^ st = Convert::ToString(r[L"Status"]);
					if (st == L"Verified") w++;
					else if (st == L"Sent to AR") s++;
					else if (st == L"Paid") p++;
				}
				Theme::SetKpi(kWait, w.ToString());
				Theme::SetKpi(kSent, s.ToString());
				Theme::SetKpi(kPaid, p.ToString());
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoSelected(Object^ sender, EventArgs^ e)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr) return;
			txtLecturer->Text = Theme::Str(r->Cells[L"Lecturer ID"]->Value);
			txtUrl->Text = Theme::Str(r->Cells[L"Sheet URL"]->Value);
		}

		void DoOpen(Object^ sender, EventArgs^ e)
		{
			Theme::OpenLink(txtUrl->Text);
		}

		void DoSend(Object^ sender, EventArgs^ e)
		{
			int lecturer = 0;
			if (!Int32::TryParse(txtLecturer->Text->Trim(), lecturer))
			{
				Theme::MsgWarn(L"Enter the lecturer's Employee ID (a number), or select a sheet in the table.");
				return;
			}
			String^ url = txtUrl->Text->Trim();
			if (!Theme::IsWebLink(url))
			{
				Theme::MsgWarn(L"Please enter a valid payment sheet link that starts with http:// or https://");
				return;
			}
			try
			{
				// prefer the selected row, otherwise the oldest verified sheet of that lecturer
				int sheetId = 0;
				DataGridViewRow^ r = grid->CurrentRow;
				if (r != nullptr && Theme::Str(r->Cells[L"Status"]->Value) == L"Verified"
					&& Convert::ToInt32(r->Cells[L"Lecturer ID"]->Value) == lecturer)
				{
					sheetId = Convert::ToInt32(r->Cells[L"ID"]->Value);
				}
				else
				{
					sheetId = Db::ScalarInt(
						L"SELECT IFNULL(MIN(Sheet_ID), 0) FROM Payment_Sheet WHERE Employee_ID = @e AND `Status` = 'Verified'", L"@e", lecturer);
				}
				if (sheetId == 0)
				{
					Theme::MsgWarn(L"There is no HOD-verified payment sheet waiting for employee " + lecturer.ToString() + L".");
					return;
				}
				int n = Db::Exec(
					L"UPDATE Payment_Sheet SET Forward_URL = @u, Forwarded_By = @c, Forwarded_Date = @d, `Status` = 'Sent to AR' "
					L"WHERE Sheet_ID = @id AND `Status` = 'Verified'",
					L"@u", url, L"@c", S->EmployeeId, L"@d", Theme::DateValue(dtpDate), L"@id", sheetId);
				if (n == 0)
				{
					Theme::MsgWarn(L"This sheet was changed by someone else. The list has been refreshed.");
				}
				else
				{
					txtUrl->Clear();
					txtLecturer->Clear();
					Theme::MsgInfo(L"Payment sheet sent to the AR office.");
				}
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}
