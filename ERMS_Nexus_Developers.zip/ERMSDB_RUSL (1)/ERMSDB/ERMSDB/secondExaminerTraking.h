#pragma once
#include "TrakingDetails.h"

namespace ERMSDB {

	// Tracking screen of the Second Examiner (same view, different assignment type)
	public ref class secondExaminerTraking : public TrakingDetails
	{
	public:
		secondExaminerTraking(Session^ s)
			: TrakingDetails(s, L"Exam Packet Tracking", L"Progress of the courses you are second examiner for.", L"Second Examiner%")
		{
		}
	};
}
