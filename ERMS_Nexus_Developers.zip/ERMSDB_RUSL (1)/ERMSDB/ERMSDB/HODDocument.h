#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  HOD  -  course tracking records: add / update / delete
	//  Works on Exam_Offering + Exam_Packet_Tracking for one (Year, Semester, Course)
	// ------------------------------------------------------------------
	public ref class HODDocument : public BasePage
	{
	private:
		DataTable^ dtTrack;
		DataGridView^ grid;
		TextBox^ txtSearch;
		bool loading;

		ComboBox^ cmbSem;
		ComboBox^ cmbCourse;
		DateTimePicker^ dtpExam;
		NumericUpDown^ numScripts;
		ComboBox^ cmbStatus;
		DateTimePicker^ dtpSub;
		DateTimePicker^ dtpEis;
		DateTimePicker^ dtpHand;
		NumericUpDown^ numPackets;
		TextBox^ txtUrl;

	public:
		HODDocument(Session^ s)
			: BasePage(s, L"Course Tracking Records", L"Add, correct or remove exam and packet tracking records.")
		{
			loading = false;
			Build();
		}

		virtual void Reload() override
		{
			try
			{
				loading = true;
				Theme::BindCombo(cmbSem, Db::Query(Sql::SemesterList()), L"Label", L"K");
				Theme::BindCombo(cmbCourse, Db::Query(Sql::CourseList()), L"Label", L"Course_Code");
				loading = false;
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

	private:
		void AddRow(Panel^ card, String^ caption, Control^ ctl, int x, int y, int w)
		{
			card->Controls->Add(Theme::Lbl(caption, x, y + 4, 9.5f, FontStyle::Regular, Theme::Muted));
			ctl->Location = System::Drawing::Point(x + 130, y);
			ctl->Width = w;
			card->Controls->Add(ctl);
		}

		void Build()
		{
			// ------------- list -------------
			Panel^ gc = Theme::Card(28, 92, 940, 340, L"Tracking Records");
			gc->Controls->Add(Theme::Lbl(L"Search", 20, 56, 9.5f, FontStyle::Regular, Theme::Muted));
			txtSearch = Theme::Txt(80, 52, 280);
			txtSearch->TextChanged += gcnew EventHandler(this, &HODDocument::DoSearch);
			gc->Controls->Add(txtSearch);
			gc->Controls->Add(Theme::Lbl(L"(course code or name)", 372, 56, 9.0f, FontStyle::Italic, Theme::Muted));

			grid = Theme::Grid(20, 92, 900, 230);
			grid->SelectionChanged += gcnew EventHandler(this, &HODDocument::DoRowSelected);
			gc->Controls->Add(grid);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);

			// ------------- editor -------------
			Panel^ ec = Theme::Card(28, 452, 940, 350, L"Edit / Add Record");
			cmbSem = Theme::Combo(0, 0, 100);
			cmbCourse = Theme::Combo(0, 0, 100);
			dtpExam = Theme::DatePick(0, 0, 100, false);
			numScripts = Theme::Num(0, 0, 100, 0, 5000, 0);
			cmbStatus = Theme::Combo(0, 0, 100);
			cmbStatus->Items->Add(L"Scheduled");
			cmbStatus->Items->Add(L"Completed");
			cmbStatus->Items->Add(L"Postponed");
			cmbStatus->Items->Add(L"Cancelled");
			cmbStatus->SelectedIndex = 0;

			dtpSub = Theme::DatePick(0, 0, 100, true);
			dtpEis = Theme::DatePick(0, 0, 100, true);
			dtpHand = Theme::DatePick(0, 0, 100, true);
			numPackets = Theme::Num(0, 0, 100, 0, 5000, 0);
			txtUrl = Theme::Txt(0, 0, 100);
			txtUrl->MaxLength = 100;

			AddRow(ec, L"Semester", cmbSem, 20, 58, 270);
			AddRow(ec, L"Course", cmbCourse, 20, 102, 270);
			AddRow(ec, L"Exam date", dtpExam, 20, 146, 270);
			AddRow(ec, L"Answer scripts", numScripts, 20, 190, 270);
			AddRow(ec, L"Exam status", cmbStatus, 20, 234, 270);

			AddRow(ec, L"Packet submitted", dtpSub, 470, 58, 270);
			AddRow(ec, L"EIS update", dtpEis, 470, 102, 270);
			AddRow(ec, L"Handover", dtpHand, 470, 146, 270);
			AddRow(ec, L"Packet count", numPackets, 470, 190, 270);
			AddRow(ec, L"Document link", txtUrl, 470, 234, 270);

			ec->Controls->Add(Theme::Lbl(L"Saving creates the record, or updates it when the semester + course already exist.  Packet count 0 = not recorded.  Untick a date to clear it.", 20, 280, 8.5f, FontStyle::Italic, Theme::Muted));

			Button^ btnSave = Theme::Btn(L"Save Record", 20, 302, 170, 40, 0);
			Button^ btnDel = Theme::Btn(L"Delete Record", 202, 302, 170, 40, 2);
			Button^ btnClr = Theme::Btn(L"Clear", 384, 302, 100, 40, 1);
			btnSave->Click += gcnew EventHandler(this, &HODDocument::DoSave);
			btnDel->Click += gcnew EventHandler(this, &HODDocument::DoDelete);
			btnClr->Click += gcnew EventHandler(this, &HODDocument::DoClear);
			ec->Controls->Add(btnSave);
			ec->Controls->Add(btnDel);
			ec->Controls->Add(btnClr);
			this->Controls->Add(ec);
			StretchX(ec);

			SetScrollHeight(830);
		}

		void LoadGrid()
		{
			dtTrack = Db::Query(Sql::TrackingSelect() + Sql::TrackingOrder());
			loading = true;
			Theme::Bind(grid, dtTrack);
			loading = false;
			DoSearch(nullptr, nullptr);
		}

		void DoSearch(Object^ sender, EventArgs^ e)
		{
			if (dtTrack == nullptr) return;
			String^ t = txtSearch->Text->Trim();
			t = t->Replace(L"'", L"''")->Replace(L"[", L"")->Replace(L"]", L"")->Replace(L"*", L"")->Replace(L"%", L"");
			if (t->Length == 0) dtTrack->DefaultView->RowFilter = L"";
			else dtTrack->DefaultView->RowFilter = L"[Course Code] LIKE '%" + t + L"%' OR [Course Name] LIKE '%" + t + L"%'";
		}

		void DoRowSelected(Object^ sender, EventArgs^ e)
		{
			if (loading) return;
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr) return;

			Theme::SelectBy(cmbSem, L"K", Convert::ToString(r->Cells[L"Year"]->Value) + L"-" + Convert::ToString(r->Cells[L"Sem"]->Value));
			Theme::SelectBy(cmbCourse, L"Course_Code", r->Cells[L"Course Code"]->Value);

			Object^ exam = r->Cells[L"Exam Date"]->Value;
			if (exam != nullptr && !Convert::IsDBNull(exam)) dtpExam->Value = Convert::ToDateTime(exam);

			Object^ scripts = r->Cells[L"Scripts"]->Value;
			numScripts->Value = (scripts == nullptr || Convert::IsDBNull(scripts)) ? 0 : Convert::ToInt32(scripts);

			String^ st = Theme::Str(r->Cells[L"Status"]->Value);
			int idx = cmbStatus->FindStringExact(st);
			cmbStatus->SelectedIndex = (idx >= 0) ? idx : 0;

			Theme::SetDate(dtpSub, r->Cells[L"Packet Submitted"]->Value);
			Theme::SetDate(dtpEis, r->Cells[L"EIS Update"]->Value);
			Theme::SetDate(dtpHand, r->Cells[L"Handover"]->Value);

			Object^ pk = r->Cells[L"Packets"]->Value;
			numPackets->Value = (pk == nullptr || Convert::IsDBNull(pk)) ? 0 : Convert::ToInt32(pk);
			txtUrl->Text = Theme::Str(r->Cells[L"Document URL"]->Value);
		}

		void DoClear(Object^ sender, EventArgs^ e)
		{
			if (cmbSem->Items->Count > 0) cmbSem->SelectedIndex = 0;
			if (cmbCourse->Items->Count > 0) cmbCourse->SelectedIndex = 0;
			dtpExam->Value = DateTime::Now;
			numScripts->Value = 0;
			cmbStatus->SelectedIndex = 0;
			dtpSub->Checked = false;
			dtpEis->Checked = false;
			dtpHand->Checked = false;
			numPackets->Value = 0;
			txtUrl->Clear();
		}

		bool GetKey(int% year, int% sem, String^% code)
		{
			DataRow^ s = Theme::RowOf(cmbSem);
			DataRow^ c = Theme::RowOf(cmbCourse);
			if (s == nullptr || c == nullptr)
			{
				Theme::MsgWarn(L"Please select a semester and a course.");
				return false;
			}
			year = Convert::ToInt32(s[L"Year"]);
			sem = Convert::ToInt32(s[L"Semester_ID"]);
			code = Convert::ToString(c[L"Course_Code"]);
			return true;
		}

		void DoSave(Object^ sender, EventArgs^ e)
		{
			int year = 0;
			int sem = 0;
			String^ code = nullptr;
			if (!GetKey(year, sem, code)) return;

			String^ url = txtUrl->Text->Trim();
			if (url->Length > 0 && !url->StartsWith(L"http://") && !url->StartsWith(L"https://"))
			{
				Theme::MsgWarn(L"The document link must start with http:// or https://");
				return;
			}
			Object^ packets = DBNull::Value;
			int pk = Decimal::ToInt32(numPackets->Value);
			if (pk > 0) packets = pk;

			try
			{
				DbTx^ tx = gcnew DbTx();
				try
				{
					tx->Exec(
						L"INSERT INTO Exam_Offering (`Year`, Semester_ID, Course_Code, Exam_Date, Answer_Script_Count, `Status`) "
						L"VALUES (@y, @s, @c, @d, @n, @st) "
						L"ON DUPLICATE KEY UPDATE Exam_Date = @d, Answer_Script_Count = @n, `Status` = @st",
						L"@y", year, L"@s", sem, L"@c", code, L"@d", Theme::DateValue(dtpExam),
						L"@n", Decimal::ToInt32(numScripts->Value), L"@st", Convert::ToString(cmbStatus->SelectedItem));

					tx->Exec(
						L"INSERT INTO Exam_Packet_Tracking (`Year`, Semester_ID, Course_Code, Packet_Submission_Date, EIS_Update_Date, Handover_Date, Packet_Count, Document_URL) "
						L"VALUES (@y, @s, @c, @a, @b, @h, @p, @u) "
						L"ON DUPLICATE KEY UPDATE Packet_Submission_Date = @a, EIS_Update_Date = @b, Handover_Date = @h, Packet_Count = @p, Document_URL = @u",
						L"@y", year, L"@s", sem, L"@c", code,
						L"@a", Theme::DateValue(dtpSub), L"@b", Theme::DateValue(dtpEis), L"@h", Theme::DateValue(dtpHand),
						L"@p", packets, L"@u", Theme::NullIfEmpty(url));
					tx->Commit();
				}
				catch (Exception^)
				{
					tx->Rollback();
					throw;
				}
				LoadGrid();
				Theme::MsgInfo(L"Record saved for " + code + L".");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoDelete(Object^ sender, EventArgs^ e)
		{
			int year = 0;
			int sem = 0;
			String^ code = nullptr;
			if (!GetKey(year, sem, code)) return;
			if (!Theme::Confirm(L"Delete the exam offering and packet tracking record of " + code + L" (" + year.ToString() + L" S" + sem.ToString() + L")?\nThis cannot be undone.")) return;
			try
			{
				DbTx^ tx = gcnew DbTx();
				try
				{
					tx->Exec(L"DELETE FROM Exam_Packet_Tracking WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c", L"@y", year, L"@s", sem, L"@c", code);
					tx->Exec(L"DELETE FROM Exam_Offering WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c", L"@y", year, L"@s", sem, L"@c", code);
					tx->Commit();
				}
				catch (Exception^)
				{
					tx->Rollback();
					throw;
				}
				LoadGrid();
				Theme::MsgInfo(L"Record deleted.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}
