#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  HOD  -  verify the payment sheets uploaded by lecturers and
	//          send them on to the HOD clerk (Status: Uploaded -> Verified | Rejected)
	// ------------------------------------------------------------------
	public ref class HODPayment : public BasePage
	{
	private:
		ComboBox^ cmbFilter;
		DataGridView^ grid;
		TextBox^ txtRemarks;
		Panel^ kUp;
		Panel^ kVer;
		Panel^ kSent;
		Panel^ kPaid;
		bool loading;

	public:
		HODPayment(Session^ s)
			: BasePage(s, L"Payment Sheets", L"Verify the payment sheets uploaded by lecturers and send them to the HOD clerk.")
		{
			loading = false;
			Build();
		}

		virtual void Reload() override
		{
			LoadGrid();
		}

	private:
		void Build()
		{
			kUp = Theme::Kpi(28, 92, 220, 84, L"AWAITING VERIFICATION", L"0", Theme::Warn);
			kVer = Theme::Kpi(264, 92, 220, 84, L"WITH HOD CLERK", L"0", Theme::Good);
			kSent = Theme::Kpi(500, 92, 220, 84, L"SENT TO AR OFFICE", L"0", Theme::Info);
			kPaid = Theme::Kpi(736, 92, 220, 84, L"PAID", L"0", Theme::Brand);
			this->Controls->Add(kUp);
			this->Controls->Add(kVer);
			this->Controls->Add(kSent);
			this->Controls->Add(kPaid);

			Panel^ gc = Theme::Card(28, 196, 928, 480, L"Lecturer Payment Sheets");
			gc->Controls->Add(Theme::Lbl(L"Show", 20, 56, 9.5f, FontStyle::Regular, Theme::Muted));
			cmbFilter = Theme::Combo(64, 52, 200);
			cmbFilter->Items->Add(L"Uploaded");
			cmbFilter->Items->Add(L"Verified");
			cmbFilter->Items->Add(L"Sent to AR");
			cmbFilter->Items->Add(L"Paid");
			cmbFilter->Items->Add(L"Rejected");
			cmbFilter->Items->Add(L"All");
			cmbFilter->SelectedIndex = 0;
			cmbFilter->SelectedIndexChanged += gcnew EventHandler(this, &HODPayment::DoFilter);
			gc->Controls->Add(cmbFilter);

			grid = Theme::Grid(20, 96, 888, 250);
			gc->Controls->Add(grid);

			gc->Controls->Add(Theme::Lbl(L"Remarks", 20, 366, 9.5f, FontStyle::Regular, Theme::Muted));
			txtRemarks = Theme::Txt(90, 362, 400);
			txtRemarks->MaxLength = 100;
			gc->Controls->Add(txtRemarks);
			gc->Controls->Add(Theme::Lbl(L"(optional - shown to the lecturer)", 502, 366, 9.0f, FontStyle::Italic, Theme::Muted));

			Button^ bOpen = Theme::Btn(L"Open Sheet", 20, 414, 150, 40, 1);
			Button^ bOk = Theme::Btn(L"Verify && Send to HOD Clerk", 184, 414, 250, 40, 0);
			Button^ bNo = Theme::Btn(L"Reject", 448, 414, 120, 40, 2);
			bOpen->Click += gcnew EventHandler(this, &HODPayment::DoOpen);
			bOk->Click += gcnew EventHandler(this, &HODPayment::DoVerify);
			bNo->Click += gcnew EventHandler(this, &HODPayment::DoReject);
			gc->Controls->Add(bOpen);
			gc->Controls->Add(bOk);
			gc->Controls->Add(bNo);

			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);
			SetScrollHeight(700);
		}

		void DoFilter(Object^ sender, EventArgs^ e)
		{
			if (loading) return;
			LoadGrid();
		}

		void LoadGrid()
		{
			try
			{
				loading = true;
				String^ f = Convert::ToString(cmbFilter->SelectedItem);
				DataTable^ dt = nullptr;
				if (f == L"All" || f->Length == 0)
					dt = Db::Query(Sql::PaymentSelect() + L"ORDER BY p.Sheet_ID DESC");
				else
					dt = Db::Query(Sql::PaymentSelect() + L"WHERE p.`Status` = @st ORDER BY p.Sheet_ID DESC", L"@st", f);
				Theme::Bind(grid, dt);
				if (grid->Columns->Contains(L"AR Sheet URL")) grid->Columns[L"AR Sheet URL"]->Visible = false;

				DataTable^ c = Db::Query(L"SELECT `Status`, COUNT(*) AS N FROM Payment_Sheet GROUP BY `Status`");
				int up = 0, ver = 0, sent = 0, paid = 0;
				for each (DataRow^ r in c->Rows)
				{
					String^ st = Convert::ToString(r[L"Status"]);
					int n = Convert::ToInt32(r[L"N"]);
					if (st == L"Uploaded") up = n;
					else if (st == L"Verified") ver = n;
					else if (st == L"Sent to AR") sent = n;
					else if (st == L"Paid") paid = n;
				}
				Theme::SetKpi(kUp, up.ToString());
				Theme::SetKpi(kVer, ver.ToString());
				Theme::SetKpi(kSent, sent.ToString());
				Theme::SetKpi(kPaid, paid.ToString());
				loading = false;
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

		void DoOpen(Object^ sender, EventArgs^ e)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Select a payment sheet first.");
				return;
			}
			Theme::OpenLink(Theme::Str(r->Cells[L"Sheet URL"]->Value));
		}

		void Decide(String^ newStatus)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Select a payment sheet first.");
				return;
			}
			if (Theme::Str(r->Cells[L"Status"]->Value) != L"Uploaded")
			{
				Theme::MsgWarn(L"Only sheets with status \"Uploaded\" can be verified or rejected.");
				return;
			}
			int id = Convert::ToInt32(r->Cells[L"ID"]->Value);
			String^ who = Theme::Str(r->Cells[L"Lecturer"]->Value);
			String^ verb = (newStatus == L"Verified") ? L"Verify the payment sheet of " : L"Reject the payment sheet of ";
			if (!Theme::Confirm(verb + who + L"?")) return;
			try
			{
				int n = Db::Exec(
					L"UPDATE Payment_Sheet SET `Status` = @st, Verified_By = @e, Verified_Date = CURDATE(), Remarks = @rm "
					L"WHERE Sheet_ID = @id AND `Status` = 'Uploaded'",
					L"@st", newStatus, L"@e", S->EmployeeId, L"@rm", Theme::NullIfEmpty(txtRemarks->Text), L"@id", id);
				if (n == 0) Theme::MsgWarn(L"This sheet was changed by someone else. The list has been refreshed.");
				txtRemarks->Clear();
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoVerify(Object^ sender, EventArgs^ e)
		{
			Decide(L"Verified");
		}

		void DoReject(Object^ sender, EventArgs^ e)
		{
			Decide(L"Rejected");
		}
	};
}
