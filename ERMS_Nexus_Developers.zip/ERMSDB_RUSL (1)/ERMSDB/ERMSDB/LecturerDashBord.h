#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Lecturer in Charge  -  dashboard
	//  Lets the lecturer pick the semester/course and nominate the
	//  second examiner and moderator (stored in Admin_Course).
	// ------------------------------------------------------------------
	public ref class LecturerDashBord : public BasePage
	{
	private:
		ComboBox^ cmbSem;
		ComboBox^ cmbCourse;
		ComboBox^ cmbSecond;
		ComboBox^ cmbMod;
		DataGridView^ grid;
		Panel^ kpiCourses;
		Panel^ kpiDocs;
		Label^ lblNote;
		Label^ lblLimit;
		bool loading;
		int myRank;
		// NOTE: a lecturer in charge may now select any number of courses (no cap).
		literal int MaxSecondExaminerCourses = 4;   // one person may be nominated as second examiner on at most 4 courses in total

	public:
		LecturerDashBord(Session^ s)
			: BasePage(s, L"Lecturer Dashboard", L"Select your courses and nominate the second examiner and moderator.")
		{
			loading = false;
			myRank = 0;
			Build();
		}

		virtual void Reload() override
		{
			try
			{
				loading = true;
				myRank = Db::ScalarInt(L"SELECT " + Sql::RankOf(L"@x"), L"@x", S->EmployeeId);
				Theme::BindCombo(cmbSem, Db::Query(Sql::SemesterList()), L"Label", L"Year");
				Theme::BindCombo(cmbCourse, Db::Query(Sql::CourseList()), L"Label", L"Course_Code");

				// only second examiners of a HIGHER grade than the lecturer in charge can be nominated;
				// each candidate's current course load (out of the max) is shown in their label
				DataTable^ se = Db::Query(
					L"SELECT e.Employee_ID, CONCAT(e.Employee_ID, ' - ', e.First_Name, ' ', e.Last_Name, ' (', "
					L"IFNULL((SELECT GROUP_CONCAT(q2.Qualification SEPARATOR ', ') FROM Employee_Qualification q2 WHERE q2.Employee_ID = e.Employee_ID), 'no grade'), "
					L"', ', (SELECT COUNT(*) FROM Admin_Course a4 WHERE a4.Employee_ID = e.Employee_ID AND a4.Transaction_Type LIKE 'Second Examiner%'), "
					L"' / 4 courses)') AS Label "
					L"FROM Second_Examiner x JOIN Employee e ON e.Employee_ID = x.Employee_ID "
					L"WHERE " + Sql::RankOf(L"e.Employee_ID") + L" > @r ORDER BY e.Employee_ID", L"@r", myRank);
				Theme::BindCombo(cmbSecond, Theme::WithNone(se, L"Employee_ID", L"Label", L"(not selected)"), L"Label", L"Employee_ID");
				String^ note = L"Second examiners must hold a higher grade than you, and can serve on at most " +
					Convert::ToString(MaxSecondExaminerCourses) + L" courses in total.";
				if (se->Rows->Count == 1) note = note + L" None are available right now.";
				lblNote->Text = note;

				DataTable^ mo = Db::Query(
					L"SELECT e.Employee_ID, CONCAT(e.Employee_ID, ' - ', e.First_Name, ' ', e.Last_Name) AS Label "
					L"FROM Moderator x JOIN Employee e ON e.Employee_ID = x.Employee_ID ORDER BY e.Employee_ID");
				Theme::BindCombo(cmbMod, Theme::WithNone(mo, L"Employee_ID", L"Label", L"(not selected)"), L"Label", L"Employee_ID");

				loading = false;
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			Panel^ banner = WelcomeBanner(28, 92, 900);
			StretchX(banner);
			this->Controls->Add(banner);

			this->Controls->Add(ProfileCard(28, 178, 380));

			kpiCourses = Theme::Kpi(28, 430, 182, 84, L"COURSES SELECTED", L"0", Theme::Brand);
			kpiDocs = Theme::Kpi(226, 430, 182, 84, L"DOCUMENTS SUBMITTED", L"0", Theme::Gold);
			this->Controls->Add(kpiCourses);
			this->Controls->Add(kpiDocs);

			Panel^ card = Theme::Card(428, 178, 520, 336, L"Course & Examiner Selection");
			cmbSem = Theme::Combo(0, 0, 100);
			cmbCourse = Theme::Combo(0, 0, 100);
			cmbSecond = Theme::Combo(0, 0, 100);
			cmbMod = Theme::Combo(0, 0, 100);
			Theme::Field(card, L"Semester", cmbSem, 58);
			Theme::Field(card, L"Course", cmbCourse, 102);
			Theme::Field(card, L"Second Examiner", cmbSecond, 146);
			Theme::Field(card, L"Moderator", cmbMod, 190);
			lblNote = Theme::Lbl(L"", 20, 234, 9.0f, FontStyle::Italic, Theme::Muted);
			card->Controls->Add(lblNote);
			lblLimit = Theme::Lbl(L"", 20, 252, 9.5f, FontStyle::Bold, Theme::Bad);
			card->Controls->Add(lblLimit);
			Button^ btn = Theme::Btn(L"Save Selection", 160, 272, 190, 42, 0);
			btn->Click += gcnew EventHandler(this, &LecturerDashBord::DoAssign);
			card->Controls->Add(btn);
			this->Controls->Add(card);

			Panel^ gc = Theme::Card(28, 534, 920, 312, L"My Courses");
			grid = Theme::Grid(20, 54, 880, 196);
			gc->Controls->Add(grid);
			Button^ btnRemove = Theme::Btn(L"Remove Selected Course", 20, 260, 200, 36, 2);
			btnRemove->Click += gcnew EventHandler(this, &LecturerDashBord::DoRemove);
			gc->Controls->Add(btnRemove);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);

			SetScrollHeight(870);
		}

		void LoadGrid()
		{
			DataTable^ dt = Db::Query(
				L"SELECT ac.`Year` AS `Year`, ac.Semester_ID AS `Sem`, ac.Course_Code AS `Course Code`, c.Name AS `Course Name`, "
				L"(SELECT GROUP_CONCAT(CONCAT(e2.First_Name, ' ', e2.Last_Name) SEPARATOR ', ') FROM Admin_Course a2 "
				L"JOIN Employee e2 ON e2.Employee_ID = a2.Employee_ID WHERE a2.`Year` = ac.`Year` AND a2.Semester_ID = ac.Semester_ID "
				L"AND a2.Course_Code = ac.Course_Code AND a2.Transaction_Type LIKE 'Second Examiner%') AS `Second Examiner`, "
				L"(SELECT GROUP_CONCAT(CONCAT(e3.First_Name, ' ', e3.Last_Name) SEPARATOR ', ') FROM Admin_Course a3 "
				L"JOIN Employee e3 ON e3.Employee_ID = a3.Employee_ID WHERE a3.`Year` = ac.`Year` AND a3.Semester_ID = ac.Semester_ID "
				L"AND a3.Course_Code = ac.Course_Code AND a3.Transaction_Type LIKE 'Moderator%') AS `Moderator` "
				L"FROM Admin_Course ac JOIN Course c ON c.Course_Code = ac.Course_Code "
				L"WHERE ac.Employee_ID = @e AND ac.Transaction_Type LIKE 'Lecturer in Charge%' "
				L"ORDER BY ac.`Year` DESC, ac.Semester_ID DESC, ac.Course_Code",
				L"@e", S->EmployeeId);
			Theme::Bind(grid, dt);
			UpdateCountKpi();

			int docs = Db::ScalarInt(
				L"SELECT COUNT(*) FROM Admin_Course ac JOIN Exam_Packet_Tracking p ON p.`Year` = ac.`Year` "
				L"AND p.Semester_ID = ac.Semester_ID AND p.Course_Code = ac.Course_Code "
				L"WHERE ac.Employee_ID = @e AND ac.Transaction_Type LIKE 'Lecturer in Charge%' "
				L"AND p.Document_URL IS NOT NULL AND p.Document_URL <> ''",
				L"@e", S->EmployeeId);
			Theme::SetKpi(kpiDocs, docs.ToString());
		}

		// number of courses this lecturer has selected in total (all semesters)
		int CoursesTotal()
		{
			return Db::ScalarInt(
				L"SELECT COUNT(*) FROM Admin_Course WHERE Employee_ID = @e AND Transaction_Type LIKE 'Lecturer in Charge%'",
				L"@e", S->EmployeeId);
		}

		void UpdateCountKpi()
		{
			int n = CoursesTotal();
			Theme::SetKpi(kpiCourses, n.ToString());
			lblLimit->Text = L"";
		}

		static int PickedId(ComboBox^ cb)
		{
			DataRow^ r = Theme::RowOf(cb);
			if (r == nullptr || Convert::IsDBNull(r[L"Employee_ID"])) return 0;
			return Convert::ToInt32(r[L"Employee_ID"]);
		}

		String^ UpsertSql()
		{
			return L"INSERT INTO Admin_Course (Employee_ID, `Year`, Semester_ID, Course_Code, Transaction_Type) "
				L"VALUES (@e, @y, @s, @c, @t) "
				L"ON DUPLICATE KEY UPDATE Transaction_Type = IF(Transaction_Type LIKE CONCAT(@t, '%'), Transaction_Type, @t)";
		}

		void DoAssign(Object^ sender, EventArgs^ e)
		{
			DataRow^ sem = Theme::RowOf(cmbSem);
			DataRow^ crs = Theme::RowOf(cmbCourse);
			if (sem == nullptr || crs == nullptr)
			{
				Theme::MsgWarn(L"Please select a semester and a course.");
				return;
			}
			int year = Convert::ToInt32(sem[L"Year"]);
			int semId = Convert::ToInt32(sem[L"Semester_ID"]);
			String^ code = Convert::ToString(crs[L"Course_Code"]);
			int secId = PickedId(cmbSecond);
			int modId = PickedId(cmbMod);

			if ((secId != 0 && secId == S->EmployeeId) || (modId != 0 && modId == S->EmployeeId))
			{
				Theme::MsgWarn(L"You cannot nominate yourself as second examiner or moderator.");
				return;
			}
			if (secId != 0 && secId == modId)
			{
				Theme::MsgWarn(L"The second examiner and the moderator must be different people.");
				return;
			}

			try
			{
				// (lecturer in charge course selection is no longer capped - any number of courses is allowed)

				// rule 1b: a second examiner may be nominated for at most MaxSecondExaminerCourses courses in total
				if (secId != 0)
				{
					bool secAlreadyOnThis = Db::ScalarInt(
						L"SELECT COUNT(*) FROM Admin_Course WHERE Employee_ID = @e AND `Year` = @y AND Semester_ID = @s AND Course_Code = @c "
						L"AND Transaction_Type LIKE 'Second Examiner%'", L"@e", secId, L"@y", year, L"@s", semId, L"@c", code) > 0;
					int secTotal = Db::ScalarInt(
						L"SELECT COUNT(*) FROM Admin_Course WHERE Employee_ID = @e AND Transaction_Type LIKE 'Second Examiner%'",
						L"@e", secId);
					if (!secAlreadyOnThis && secTotal >= MaxSecondExaminerCourses)
					{
						Theme::MsgWarn(L"That second examiner has already reached the maximum of " +
							Convert::ToString(MaxSecondExaminerCourses) + L" courses.\n\n"
							L"Choose a different second examiner, or ask them to be removed from one of their existing courses first.");
						return;
					}
				}

				// rule 2: the second examiner must hold a higher grade than the lecturer in charge
				if (secId != 0)
				{
					int myR = Db::ScalarInt(L"SELECT " + Sql::RankOf(L"@x"), L"@x", S->EmployeeId);
					int secR = Db::ScalarInt(L"SELECT " + Sql::RankOf(L"@x"), L"@x", secId);
					if (secR <= myR)
					{
						Theme::MsgWarn(L"The second examiner must hold a higher grade than the lecturer in charge.\n\n"
							L"Grade order: Temporary Lecturer < Probationary Lecturer < Temporary Senior Lecturer < "
							L"Senior Lecturer Grade 2 < Senior Lecturer Grade 1 < Professor.");
						return;
					}
				}

				DbTx^ tx = gcnew DbTx();
				try
				{
					tx->Exec(UpsertSql(), L"@e", S->EmployeeId, L"@y", year, L"@s", semId, L"@c", code, L"@t", L"Lecturer in Charge");
					if (secId != 0)
					{
						tx->Exec(L"DELETE FROM Admin_Course WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c "
							L"AND Transaction_Type LIKE 'Second Examiner%' AND Employee_ID <> @e",
							L"@y", year, L"@s", semId, L"@c", code, L"@e", secId);
						tx->Exec(UpsertSql(), L"@e", secId, L"@y", year, L"@s", semId, L"@c", code, L"@t", L"Second Examiner");
					}
					if (modId != 0)
					{
						tx->Exec(L"DELETE FROM Admin_Course WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c "
							L"AND Transaction_Type LIKE 'Moderator%' AND Employee_ID <> @e",
							L"@y", year, L"@s", semId, L"@c", code, L"@e", modId);
						tx->Exec(UpsertSql(), L"@e", modId, L"@y", year, L"@s", semId, L"@c", code, L"@t", L"Moderator");
					}
					tx->Commit();
				}
				catch (Exception^)
				{
					tx->Rollback();
					throw;
				}
				LoadGrid();
				Theme::MsgInfo(L"Selection saved for " + code + L".");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoRemove(Object^ sender, EventArgs^ e)
		{
			DataGridViewRow^ r = grid->CurrentRow;
			if (r == nullptr)
			{
				Theme::MsgWarn(L"Select a course in the table first.");
				return;
			}
			int year = Convert::ToInt32(r->Cells[L"Year"]->Value);
			int semId = Convert::ToInt32(r->Cells[L"Sem"]->Value);
			String^ code = Convert::ToString(r->Cells[L"Course Code"]->Value);
			if (!Theme::Confirm(L"Remove " + code + L" and its examiner / moderator nominations from your list?")) return;
			try
			{
				Db::Exec(
					L"DELETE FROM Admin_Course WHERE `Year` = @y AND Semester_ID = @s AND Course_Code = @c AND "
					L"((Employee_ID = @e AND Transaction_Type LIKE 'Lecturer in Charge%') "
					L"OR Transaction_Type LIKE 'Second Examiner%' OR Transaction_Type LIKE 'Moderator%')",
					L"@y", year, L"@s", semId, L"@c", code, L"@e", S->EmployeeId);
				LoadGrid();
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}