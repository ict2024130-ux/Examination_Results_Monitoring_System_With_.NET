#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Lecturer in Charge  -  exam document submission
	//    Exam paper link      -> Exam_Packet_Tracking.Document_URL
	//    Detail mark sheet    -> Exam_Document (Doc_Type = 'Mark Sheet')   [needs ERMS_update.sql]
	// ------------------------------------------------------------------
	public ref class docup : public BasePage
	{
	private:
		ComboBox^ cmbCourse;
		TextBox^ txtCurrent;
		TextBox^ txtUrl;
		TextBox^ txtMarkCurrent;
		TextBox^ txtMarkUrl;
		Label^ lblHint;
		DataGridView^ grid;
		bool loading;

	public:
		docup(Session^ s)
			: BasePage(s, L"Document Submission", L"Submit the exam paper link and the detail mark sheet for your course.")
		{
			loading = false;
			Build();
		}

		virtual void Reload() override
		{
			try
			{
				loading = true;
				DataTable^ dt = Db::Query(
					L"SELECT ac.`Year` AS `Year`, ac.Semester_ID AS Semester_ID, ac.Course_Code AS Course_Code, "
					L"CONCAT(ac.`Year`, ' S', ac.Semester_ID, '  |  ', ac.Course_Code, ' - ', c.Name) AS Label, "
					L"IFNULL(p.Document_URL, '') AS Url, "
					L"IFNULL((SELECT d.Document_URL FROM Exam_Document d WHERE d.`Year` = ac.`Year` AND d.Semester_ID = ac.Semester_ID "
					L"AND d.Course_Code = ac.Course_Code AND d.Doc_Type = 'Mark Sheet'), '') AS MarkUrl "
					L"FROM Admin_Course ac JOIN Course c ON c.Course_Code = ac.Course_Code "
					L"LEFT JOIN Exam_Packet_Tracking p ON p.`Year` = ac.`Year` AND p.Semester_ID = ac.Semester_ID AND p.Course_Code = ac.Course_Code "
					L"WHERE ac.Employee_ID = @e AND ac.Transaction_Type LIKE 'Lecturer in Charge%' "
					L"ORDER BY ac.`Year` DESC, ac.Semester_ID DESC, ac.Course_Code",
					L"@e", S->EmployeeId);
				Theme::BindCombo(cmbCourse, dt, L"Label", L"Course_Code");
				loading = false;

				if (dt->Rows->Count == 0)
					lblHint->Text = L"You have not selected any course yet. Open the Dashboard and choose your courses first.";
				else
					lblHint->Text = L"Paste a link (http / https) to the shared folder or file that holds the documents.";

				ShowCurrent();
				Theme::Bind(grid, dt->Copy());   // separate copy so the grid does not share the combo's position
				HideHelperColumns();
			}
			catch (Exception^ ex)
			{
				loading = false;
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			// ---------- exam paper ----------
			Panel^ card = Theme::Card(28, 92, 640, 290, L"Exam Paper Link");
			cmbCourse = Theme::Combo(0, 0, 100);
			txtCurrent = Theme::Txt(0, 0, 100);
			txtCurrent->ReadOnly = true;
			txtCurrent->BackColor = Theme::Bg;
			txtUrl = Theme::Txt(0, 0, 100);
			txtUrl->MaxLength = 100;
			Theme::Field(card, L"Course", cmbCourse, 58);
			Theme::Field(card, L"Current link", txtCurrent, 102);
			Theme::Field(card, L"New link", txtUrl, 146);
			lblHint = Theme::Lbl(L"", 20, 190, 9.0f, FontStyle::Italic, Theme::Muted);
			card->Controls->Add(lblHint);

			Button^ btnSave = Theme::Btn(L"Submit Paper", 160, 228, 190, 42, 0);
			Button^ btnOpen = Theme::Btn(L"Open Current Link", 362, 228, 180, 42, 1);
			btnSave->Click += gcnew EventHandler(this, &docup::DoSave);
			btnOpen->Click += gcnew EventHandler(this, &docup::DoOpen);
			card->Controls->Add(btnSave);
			card->Controls->Add(btnOpen);
			this->Controls->Add(card);

			// ---------- detail mark sheet ----------
			Panel^ mk = Theme::Card(28, 402, 640, 230, L"Detail Mark Sheet (for the second examiner)");
			txtMarkCurrent = Theme::Txt(0, 0, 100);
			txtMarkCurrent->ReadOnly = true;
			txtMarkCurrent->BackColor = Theme::Bg;
			txtMarkUrl = Theme::Txt(0, 0, 100);
			txtMarkUrl->MaxLength = 200;
			Theme::Field(mk, L"Current link", txtMarkCurrent, 58);
			Theme::Field(mk, L"New link", txtMarkUrl, 102);
			Button^ btnMark = Theme::Btn(L"Submit Mark Sheet", 160, 156, 190, 42, 0);
			Button^ btnMarkOpen = Theme::Btn(L"Open Current Link", 362, 156, 180, 42, 1);
			btnMark->Click += gcnew EventHandler(this, &docup::DoSaveMark);
			btnMarkOpen->Click += gcnew EventHandler(this, &docup::DoOpenMark);
			mk->Controls->Add(btnMark);
			mk->Controls->Add(btnMarkOpen);
			this->Controls->Add(mk);

			Panel^ info = Theme::Card(688, 92, 280, 540, L"Guidelines");
			info->Controls->Add(Theme::Lbl(L"1.  Upload the paper and marking\n     scheme to your shared storage.", 20, 58, 9.5f, FontStyle::Regular, Theme::Ink));
			info->Controls->Add(Theme::Lbl(L"2.  Paste the sharing link here.", 20, 112, 9.5f, FontStyle::Regular, Theme::Ink));
			info->Controls->Add(Theme::Lbl(L"3.  Submit the detail mark sheet\n     after marking. The second\n     examiner opens it from the\n     Document Submission screen.", 20, 152, 9.5f, FontStyle::Regular, Theme::Ink));
			info->Controls->Add(Theme::Lbl(L"4.  The moderator and second\n     examiner can open the paper\n     from their dashboards.", 20, 244, 9.5f, FontStyle::Regular, Theme::Ink));
			info->Controls->Add(Theme::Lbl(L"Paper link: max 100 characters.\nMark sheet link: max 200.", 20, 340, 9.0f, FontStyle::Italic, Theme::Muted));
			this->Controls->Add(info);

			Panel^ gc = Theme::Card(28, 652, 940, 290, L"My Submissions");
			grid = Theme::Grid(20, 54, 900, 214);
			gc->Controls->Add(grid);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);

			cmbCourse->SelectedIndexChanged += gcnew EventHandler(this, &docup::DoCourseChanged);
			SetScrollHeight(970);
		}

		void HideHelperColumns()
		{
			if (grid->Columns->Contains(L"Year")) grid->Columns[L"Year"]->Visible = false;
			if (grid->Columns->Contains(L"Semester_ID")) grid->Columns[L"Semester_ID"]->Visible = false;
			if (grid->Columns->Contains(L"Course_Code")) grid->Columns[L"Course_Code"]->Visible = false;
			if (grid->Columns->Contains(L"Label")) grid->Columns[L"Label"]->HeaderText = L"Course";
			if (grid->Columns->Contains(L"Url")) grid->Columns[L"Url"]->HeaderText = L"Paper Link";
			if (grid->Columns->Contains(L"MarkUrl")) grid->Columns[L"MarkUrl"]->HeaderText = L"Mark Sheet Link";
		}

		static String^ OrNone(String^ u)
		{
			if (u->Length == 0) return L"(nothing submitted yet)";
			return u;
		}

		void ShowCurrent()
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r == nullptr)
			{
				txtCurrent->Text = L"";
				txtMarkCurrent->Text = L"";
				return;
			}
			txtCurrent->Text = OrNone(Theme::Str(r[L"Url"]));
			txtMarkCurrent->Text = OrNone(Theme::Str(r[L"MarkUrl"]));
		}

		void DoCourseChanged(Object^ sender, EventArgs^ e)
		{
			if (loading) return;
			ShowCurrent();
		}

		void DoSave(Object^ sender, EventArgs^ e)
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r == nullptr)
			{
				Theme::MsgWarn(L"You have no course to submit a document for.");
				return;
			}
			String^ url = txtUrl->Text->Trim();
			if (!Theme::IsWebLink(url))
			{
				Theme::MsgWarn(L"Please enter a valid link that starts with http:// or https://");
				return;
			}
			try
			{
				int idx = cmbCourse->SelectedIndex;
				Db::Exec(
					L"INSERT INTO Exam_Packet_Tracking (`Year`, Semester_ID, Course_Code, Document_URL) VALUES (@y, @s, @c, @u) "
					L"ON DUPLICATE KEY UPDATE Document_URL = @u",
					L"@y", Convert::ToInt32(r[L"Year"]), L"@s", Convert::ToInt32(r[L"Semester_ID"]),
					L"@c", Convert::ToString(r[L"Course_Code"]), L"@u", url);
				txtUrl->Clear();
				Reload();
				if (idx >= 0 && idx < cmbCourse->Items->Count) cmbCourse->SelectedIndex = idx;
				Theme::MsgInfo(L"Paper link submitted.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoSaveMark(Object^ sender, EventArgs^ e)
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r == nullptr)
			{
				Theme::MsgWarn(L"You have no course to submit a mark sheet for.");
				return;
			}
			String^ url = txtMarkUrl->Text->Trim();
			if (!Theme::IsWebLink(url))
			{
				Theme::MsgWarn(L"Please enter a valid link that starts with http:// or https://");
				return;
			}
			try
			{
				int idx = cmbCourse->SelectedIndex;
				Db::Exec(
					L"INSERT INTO Exam_Document (`Year`, Semester_ID, Course_Code, Doc_Type, Document_URL, Submitted_By, Submitted_Date) "
					L"VALUES (@y, @s, @c, 'Mark Sheet', @u, @e, CURDATE()) "
					L"ON DUPLICATE KEY UPDATE Document_URL = @u, Submitted_By = @e, Submitted_Date = CURDATE()",
					L"@y", Convert::ToInt32(r[L"Year"]), L"@s", Convert::ToInt32(r[L"Semester_ID"]),
					L"@c", Convert::ToString(r[L"Course_Code"]), L"@u", url, L"@e", S->EmployeeId);
				txtMarkUrl->Clear();
				Reload();
				if (idx >= 0 && idx < cmbCourse->Items->Count) cmbCourse->SelectedIndex = idx;
				Theme::MsgInfo(L"Detail mark sheet submitted.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

		void DoOpen(Object^ sender, EventArgs^ e)
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r != nullptr) Theme::OpenLink(Theme::Str(r[L"Url"]));
		}

		void DoOpenMark(Object^ sender, EventArgs^ e)
		{
			DataRow^ r = Theme::RowOf(cmbCourse);
			if (r != nullptr) Theme::OpenLink(Theme::Str(r[L"MarkUrl"]));
		}
	};
}
