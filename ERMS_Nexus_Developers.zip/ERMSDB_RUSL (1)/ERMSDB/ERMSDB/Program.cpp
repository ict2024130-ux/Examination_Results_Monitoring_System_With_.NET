#include "LOGING.h"
#include "MainShell.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace ERMSDB;

[STAThreadAttribute]
int main(array<String^>^ args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	bool again = true;
	while (again)
	{
		again = false;
		LOGING^ login = gcnew LOGING();
		if (login->ShowDialog() == System::Windows::Forms::DialogResult::OK && login->Result != nullptr)
		{
			Session^ sess = login->Result;
			bool open = true;
			while (open)
			{
				open = false;
				MainShell^ shell = gcnew MainShell(sess);
				shell->ShowDialog();
				if (shell->SwitchRequested) open = true;          // "Switch Role": reopen with the new role
				else again = shell->LoggedOut;                    // "Log Out": back to sign-in; closing the window exits
			}
		}
	}
	return 0;
}
