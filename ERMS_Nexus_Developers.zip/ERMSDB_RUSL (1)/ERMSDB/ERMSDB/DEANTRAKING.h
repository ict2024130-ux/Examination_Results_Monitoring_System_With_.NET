#pragma once
#include "HODTraking.h"

namespace ERMSDB {

	// Dean: read-only employee directory with course involvement
	public ref class DEANTRAKING : public HODTraking
	{
	public:
		DEANTRAKING(Session^ s)
			: HODTraking(s, L"Employee Directory", L"Staff details and the courses they are involved in (read only).", false)
		{
		}
	};
}
