#pragma once
#include "BasePage.h"

namespace ERMSDB {

	using namespace System;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Windows::Forms;

	// ------------------------------------------------------------------
	//  Lecturer / Second Examiner / Moderator: upload a payment sheet link
	//  and follow it through HOD verification -> HOD clerk -> AR office.
	// ------------------------------------------------------------------
	public ref class PaymentSheetUpload : public BasePage
	{
	private:
		TextBox^ txtWho;
		TextBox^ txtUrl;
		DateTimePicker^ dtpDate;
		DataGridView^ grid;

	public:
		PaymentSheetUpload(Session^ s)
			: BasePage(s, L"Payment Sheet", L"Upload your payment sheet and follow its approval until it is paid.")
		{
			Build();
		}

		virtual void Reload() override
		{
			try
			{
				Theme::Bind(grid, Db::Query(
					Sql::PaymentSelect() + L"WHERE p.Employee_ID = @e ORDER BY p.Sheet_ID DESC", L"@e", S->EmployeeId));
				if (grid->Columns->Contains(L"Lecturer ID")) grid->Columns[L"Lecturer ID"]->Visible = false;
				if (grid->Columns->Contains(L"Lecturer")) grid->Columns[L"Lecturer"]->Visible = false;
				if (grid->Columns->Contains(L"AR Sheet URL")) grid->Columns[L"AR Sheet URL"]->Visible = false;
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}

	private:
		void Build()
		{
			Panel^ card = Theme::Card(28, 92, 640, 270, L"Upload Payment Sheet");
			txtWho = Theme::Txt(0, 0, 100);
			txtWho->ReadOnly = true;
			txtWho->BackColor = Theme::Bg;
			txtWho->Text = S->EmployeeId.ToString() + L" - " + S->FullName();
			txtUrl = Theme::Txt(0, 0, 100);
			txtUrl->MaxLength = 200;
			dtpDate = Theme::DatePick(0, 0, 100, false);
			Theme::Field(card, L"Lecturer", txtWho, 58);
			Theme::Field(card, L"Payment sheet URL", txtUrl, 102);
			Theme::Field(card, L"Submission date", dtpDate, 146);
			Button^ b = Theme::Btn(L"Submit Payment Sheet", 160, 202, 210, 42, 0);
			b->Click += gcnew EventHandler(this, &PaymentSheetUpload::DoSubmit);
			card->Controls->Add(b);
			this->Controls->Add(card);

			Panel^ info = Theme::Card(688, 92, 280, 270, L"Approval steps");
			info->Controls->Add(Theme::Lbl(L"1.  Uploaded   - you", 20, 58, 9.5f, FontStyle::Regular, Theme::Warn));
			info->Controls->Add(Theme::Lbl(L"2.  Verified   - HOD", 20, 92, 9.5f, FontStyle::Regular, Theme::Good));
			info->Controls->Add(Theme::Lbl(L"3.  Sent to AR - HOD clerk", 20, 126, 9.5f, FontStyle::Regular, Theme::Info));
			info->Controls->Add(Theme::Lbl(L"4.  Paid       - AR office", 20, 160, 9.5f, FontStyle::Regular, Theme::Good));
			info->Controls->Add(Theme::Lbl(L"A rejected sheet shows the HOD's\nremark; upload a corrected one.", 20, 204, 9.0f, FontStyle::Italic, Theme::Muted));
			this->Controls->Add(info);

			Panel^ gc = Theme::Card(28, 382, 940, 330, L"My Payment Sheets");
			grid = Theme::Grid(20, 54, 900, 256);
			gc->Controls->Add(grid);
			this->Controls->Add(gc);
			StretchX(gc);
			StretchIn(grid, gc);
			SetScrollHeight(740);
		}

		void DoSubmit(Object^ sender, EventArgs^ e)
		{
			String^ url = txtUrl->Text->Trim();
			if (!Theme::IsWebLink(url))
			{
				Theme::MsgWarn(L"Please enter a valid link that starts with http:// or https://");
				return;
			}
			try
			{
				Db::Exec(L"INSERT INTO Payment_Sheet (Employee_ID, Sheet_URL, Uploaded_Date, `Status`) VALUES (@e, @u, @d, 'Uploaded')",
					L"@e", S->EmployeeId, L"@u", url, L"@d", Theme::DateValue(dtpDate));
				txtUrl->Clear();
				Reload();
				Theme::MsgInfo(L"Payment sheet uploaded. It is now waiting for HOD verification.");
			}
			catch (Exception^ ex)
			{
				Theme::Fail(ex);
			}
		}
	};
}
