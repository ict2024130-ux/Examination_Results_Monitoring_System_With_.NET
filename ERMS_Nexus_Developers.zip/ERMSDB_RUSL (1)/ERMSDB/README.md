# 🔐 Employee Login Credentials

This document contains the employee login details and assigned roles for the **Examination Results Monitoring System (ERMS)**.

## 👥 Employee Login Details

| Employee ID | Password (Sign-In) | Role |
|:---:|:---|:---|
| 1 | `ar123` | AR Office |
| 4 | `sec123` | Second Examiner |
| 5 | `mod123` | Moderator |
| 7 | `lic123` | Lecturer in Charge |
| 10 | `dean123` | Dean |
| 13 | `hod123` | HOD |
| 19 | `Clerk@2026` | HOD Clerk |

