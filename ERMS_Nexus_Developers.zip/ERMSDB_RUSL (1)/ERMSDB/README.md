# ERMS - Examination Report Monitoring System (Rajarata University of Sri Lanka)

Visual Studio C++/CLI WinForms app wired to the MySQL database `ERMS`.

## Setup
1. In MySQL run `ERMS.sql`, then **`ERMS_update.sql`** (new tables for second-examiner documents + payment sheets,
   and a demo HOD clerk), then (optional) `ERMS_demo_assignments.sql`.
2. Open `ERMSDB.slnx`. Check the **MySql.Data** reference path in the project (it still points to
   `..\..\..\softwaer\v4.6.2\MySql.Data.dll` as in your original project).
3. Build & run. Connection string = `Db.h` -> `ConnStr` (root / 1234 / localhost:3306 / ERMS).
   For MySQL 8 authentication errors append `AllowPublicKeyRetrieval=true;`.
4. Images are loaded from `assets\` (copied to `<output>\Images` after build).
   To use a real campus photo on the login screen, add `campus.jpg` to `assets\`.

## Logins (Employee ID / password, from the `Users` table)
| ID | Password | Opens as |
|----|----------|----------|
| 7  | lic123   | Lecturer in Charge |
| 4  | sec123   | Second Examiner |
| 5  | mod123   | Moderator |
| 13 | hod123   | HOD |
| 10 | dean123  | Dean |
| 1  | ar123    | AR Office |
| 19 | clerk123 | HOD Clerk (created by `ERMS_update.sql`) |

An employee with several roles (e.g. ID 4 = Second Examiner + HOD Clerk, ID 10 = Dean + Lecturer in Charge)
signs in with the first role and can use **Switch Role** at the bottom of the side menu.

Default role = Dean > HOD > Second Examiner > Moderator > Lecturer in Charge > HOD Clerk > otherwise AR Office.

## How data maps to the schema (no schema changes)
* Course / examiner / moderator nominations are rows in `Admin_Course` (`Transaction_Type` = `Lecturer in Charge`,
  `Second Examiner`, `Moderator`, `Moderator - Verified`).
* Document link -> `Exam_Packet_Tracking.Document_URL` (one link per course).
* AR collect -> Packet_Submission_Date + Packet_Count; EIS update -> EIS_Update_Date; hand over -> Handover_Date + `Hand_Over`.
* Tracking "Stage": Pending -> Packet submitted -> EIS updated -> Handed over.

## Payment sheet workflow (table `Payment_Sheet`)
Lecturer / Second Examiner / Moderator **upload** -> HOD **verifies** (or rejects, with remarks) and sends to the HOD clerk
-> HOD Clerk **submits to AR office** (URL + lecturer ID + date) -> AR Office opens the sheet and marks it **Paid**.

## Second examiner documents (table `Exam_Document`)
* Lecturer in Charge: *Document Submission* now also takes the **detail mark sheet** link.
* Second Examiner: *Document Submission* submits the **second examiner report** and opens the lecturer's mark sheet.

## Known limits
* Passwords are stored/compared as plain text (as in your `Users` table). Hash them before real use.
* The old designer forms (and `.resx` files) were replaced by code-built screens inside one main window.
* Icons use the *Segoe MDL2 Assets* font (Windows 10/11).
